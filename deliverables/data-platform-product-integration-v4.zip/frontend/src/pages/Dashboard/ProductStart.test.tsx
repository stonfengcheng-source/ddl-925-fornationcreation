import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom';
import ProductStart from './ProductStart';
import { createExampleGovernanceTask } from '@/services/api/preprojectData';

vi.mock('@/services/request', () => ({default: {get: vi.fn().mockResolvedValue({asset_count: 0, running_tasks: 0, pending_reviews: 0, qualified_versions: 0, experiment_count: null, training_ready: false, recent_tasks: []})}}));
vi.mock('@/services/api/preprojectData', () => ({createExampleGovernanceTask: vi.fn()}));
const Location = () => { const location = useLocation(); return <div>{location.pathname}{location.search}</div>; };

describe('工作台首次使用', () => {
  it('创建示例后携带来源和任务进入治理监控', async () => {
    vi.mocked(createExampleGovernanceTask).mockResolvedValue({source: {source_id: 'source-id'} as never, task: {task_id:'task-id'} as never, synthetic:true});
    render(<MemoryRouter initialEntries={['/app/dashboard']}><Routes>
      <Route path="/app/dashboard" element={<ProductStart />} /><Route path="/app/data-governance/tasks" element={<Location />} />
    </Routes></MemoryRouter>);
    fireEvent.click(screen.getByRole('button', {name:'创建示例数据治理任务'}));
    await waitFor(() => expect(screen.getByText('/app/data-governance/tasks?source_id=source-id&task_id=task-id')).toBeInTheDocument());
  });
});
