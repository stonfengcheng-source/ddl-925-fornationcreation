import type { Metric } from '../types';
export function formatMetric(name: string, value: unknown): string {
  if (value === null || value === undefined) return 'N/A';
  if (typeof value === 'number') return /(?:rate|ratio|coverage)$/.test(name) ? `${(value * 100).toFixed(2)}%` : value.toLocaleString(undefined, { maximumFractionDigits: 6 });
  return typeof value === 'object' ? JSON.stringify(value) : String(value);
}
export function QualityMetricCard({ name, metric }: { name: string; metric: Metric }) {
  return <div className="border-t pt-2 text-sm"><div className="flex justify-between gap-2"><b>{name}</b><span>{formatMetric(name, metric.value)}</span></div><p className="text-xs">分子 / 分母：{metric.numerator ?? 'N/A'} / {metric.denominator ?? 'N/A'}</p><p className="text-xs">{metric.formula || metric.definition || '无公式'} · {metric.scope || '范围未提供'}</p>{metric.not_measurable_reason && <p className="text-xs text-amber-700">{metric.not_measurable_reason}</p>}</div>;
}
