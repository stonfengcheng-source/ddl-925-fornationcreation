# 预立项教育文本数据质量报告

本报告汇总本次数据流水线实际读取的记录、清洗与分流结果。五维质量画像描述数据属性，不代表模型训练收益；效用预测和 Proxy 训练验证属于后续阶段。

## 数据来源与使用范围

- 数据集：`ecnu-icalk/educhat-sft-002-data-osm`
- 来源页面：https://huggingface.co/datasets/ecnu-icalk/educhat-sft-002-data-osm
- Revision：`289618b953588bbd1b2a6e217cdd2c53e9cbcf49`
- split/config：`train` / `default`
- 许可：`cc-by-nc-4.0`；商业使用与再分发许可：未获确认，结果限本地研究处理。

## 处理流程

数据接入 → Schema 标准化 → 确定性清洗 → 完全/归一化/近似去重 → 敏感信息脱敏 → 残留复检 → 五维质量画像 → 质量准入 → JSONL 导出

## 规模与流转

- 非空输入行：200
- 可解析 JSON 对象：200
- 非法 JSON 或非对象记录：0
- 完全重复：0；归一化重复：0；近重复待审样本：0
- 脱敏命中：0；执行替换/字段移除：0；残留：0
- keep：200；repair_pending：0；review：0；quarantine：0；drop：0
- 已处理记录：200；合格数据池：200

## 五维指标

| 维度 | 指标 | 公式 | 分子 / 分母 | 实际结果 | 不可测原因或限定 |
|---|---|---|---|---|---|
| completeness | valid_sft_structure_rate | valid normalized instruction/target pairs / parsed records | 200 / 200 | 1.000000 (100.00%) |  |
| completeness | required_field_completeness_rate | samples with all required fields / samples checked | 200 / 200 | 1.000000 (100.00%) |  |
| completeness | required_field_cell_presence_rate | non-empty required field cells / (parsed samples * required field count) | 2800 / 2800 | 1.000000 (100.00%) |  |
| completeness | parseable_sample_rate | parsed JSON objects / nonblank input records | 200 / 200 | 1.000000 (100.00%) |  |
| completeness | necessary_label_coverage | records with assistant target / parsed records | 200 / 200 | 1.000000 (100.00%) |  |
| consistency | schema_consistency_rate | schema-valid records / parsed records | 200 / 200 | 1.000000 (100.00%) |  |
| consistency | answer_conflict_groups | conflict groups / groups with repeated normalized questions | 0 / 0 | None | No authoritative answer key or human adjudication is available; this is not an error count. |
| consistency | cross_modal_match_rate | N/A | None / None | None | No paired image/audio assets are present in this text-only source. |
| consistency | reviewer_agreement_rate | N/A | None / None | None | No independent double-review labels are available. |
| diversity | category_coverage | observed inferred categories / configured categories | 5 / 5 | 1.000000 (100.00%) |  |
| diversity | normalized_category_entropy | -sum(p[c] * ln(p[c])) / ln(observed category count) | 1.1905884 / 1.60943791 | 0.739754 (73.98%) |  |
| diversity | long_tail_category_coverage | count(categories with share <= 0.05) | 0 / 5 | {"categories": [], "count": 0, "share_threshold": 0.05} |  |
| diversity | near_duplicate_ratio | near-duplicate sample count / parsed sample count | 0 / 200 | 0.000000 (0.00%) |  |
| unbiasedness | reference_distribution_difference | N/A | None / None | None | No reliable reference distribution was supplied; no unbiasedness score is inferred. |
| unbiasedness | source_distribution | count(source_id) / parsed sample count | 200 / 200 | {"huggingface:ecnu-icalk/educhat-sft-002-data-osm": 200} |  |
| timeliness | published_at_coverage | valid publication timestamps / parsed records | 0 / 200 | 0.000000 (0.00%) |  |
| timeliness | data_age_days | processed_at - published_at | 0 / 200 | None | No valid publication timestamps. |
| timeliness | confirmed_expired_ratio | confirmed expired records / records with verifiable validity | None / None | None | Publication age alone does not establish expiration; no validity evidence was supplied. |
| timeliness | older_than_threshold_ratio | known dates older than 730.0 days / records with valid published_at | None / None | None | No valid published_at timestamps; missing publication time is not treated as expired. |
| timeliness | time_anomalies | count(invalid or future timestamps) | 0 / 200 | {"future_date_count": 0, "invalid_date_count": 0} |  |

### 类别画像

类别标签由配置中的关键词规则估计，未经过人工标注。

```json
{
  "classification": "heuristic_estimate",
  "source": "config.topic_keywords; rule-based and not human-verified",
  "counts": {
    "language": 16,
    "mathematics": 33,
    "other_unclassified": 121,
    "programming": 17,
    "science": 13
  },
  "observed_category_count": 5
}
```

## 质量准入结论

- 结论：**local_research_candidate**
- 原因：来源 revision 或许可未通过官方核验；本次输出仅可视为本地导入的待核实候选。；未同时满足许可核验、可再分发许可和明确再分发授权；输出不是可发布数据版本。
- 近重复样本仅进入人工复核，不自动删除。未提供参考分布时，无偏性指标为 N/A；未提供发布时间时，不推断数据过期。

## 典型问题与遗留风险

- 需要复核 `review_queue.jsonl` 中的近重复、答案冲突和编码异常样本。
- 关键词类别是估计标签，不应作为人工真值。
- CC BY-NC 4.0 不支持默认商业使用或再分发；发布、商业训练或产品化前须取得相应授权。
- 五维质量指标不能替代模型训练效用实测。
