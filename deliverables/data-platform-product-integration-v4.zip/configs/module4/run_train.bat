@echo off
chcp 65001 >nul
setlocal
"C:\Users\wh\.conda\envs\good-for-all\python.exe" -u "D:\PythonProject\clean\scripts\module4\07_run_llamafactory.py" train --variants all --config-dir "D:\PythonProject\clean\configs\module4"
exit /b %errorlevel%
