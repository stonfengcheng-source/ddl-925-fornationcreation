import * as React from 'react';
import { createPreprojectTask } from '@/services/api/preprojectData';
import { useWorkspace } from '../layout/PreprojectLayout';

export function PipelinePage() {
  const { sourceId, sources, go } = useWorkspace();
  const [clean, setClean] = React.useState(() => sessionStorage.getItem('pp-clean') !== 'false');
  const [near, setNear] = React.useState(() => sessionStorage.getItem('pp-near') !== 'false');
  const [distance, setDistance] = React.useState(() => Number(sessionStorage.getItem('pp-distance') ?? 3));
  const [name, setName] = React.useState(() => sessionStorage.getItem('pp-version') || 'local-preproject-run');
  const [busy, setBusy] = React.useState(false); const [error, setError] = React.useState('');
  const validated = Boolean(sourceId && sessionStorage.getItem('pp-validated-source') === sourceId);
  React.useEffect(() => { sessionStorage.setItem('pp-clean', String(clean)); sessionStorage.setItem('pp-near', String(near)); sessionStorage.setItem('pp-distance', String(distance)); sessionStorage.setItem('pp-version', name); }, [clean, near, distance, name]);
  const submit = async () => { if (!validated || !name.trim() || !Number.isInteger(distance) || distance < 0 || distance > 64) { setError('请先验证数据，并填写有效的版本及阈值。'); return; } setBusy(true); setError(''); try { const result = await createPreprojectTask({ source_id: sourceId, cleaning_enabled: clean, near_duplicate_enabled: near, near_duplicate_hamming_distance: distance, near_duplicate_action: 'review_only', privacy_enabled: true, version_name: name }); go('tasks', { task_id: result.task.task_id, source_id: sourceId }); } catch { setError('任务创建失败，请核验数据源后重试。'); } finally { setBusy(false); } };
  return <section className="rounded-xl border bg-white p-5 space-y-4"><h2 className="text-lg font-semibold">处理配置</h2><p>数据：{sources.find((item) => item.source_id === sourceId)?.dataset_id || '未选择'} · {sources.find((item) => item.source_id === sourceId)?.sample_count ?? 'N/A'} 条</p>
    <div className="grid gap-3 md:grid-cols-2"><div className="rounded border p-3"><b>基础清洗</b><p>Schema、对话结构、空字段、编码和长度检查。</p><label><input type="checkbox" checked={clean} onChange={(e) => setClean(e.target.checked)} /> 执行格式清洗</label></div><div className="rounded border p-3"><b>去重</b><p>完全和归一化重复；近重复仅进入复核。</p><label><input type="checkbox" checked={near} onChange={(e) => setNear(e.target.checked)} /> 检测近重复</label><label className="block">SimHash 距离阈值 <input aria-label="近重复阈值" type="number" min="0" max="64" value={distance} onChange={(e) => setDistance(Number(e.target.value))} className="w-20 rounded border p-1" /></label></div><div className="rounded border p-3"><b>隐私保护 · 必须执行</b><p>手机号、邮箱、身份证规则检测、脱敏与残留复检。</p></div><div className="rounded border p-3"><b>五维质量 · 必须执行</b><p>完整性、一致性、多元性、无偏性、时效性。</p></div></div>
    <label className="block">输出版本名称 <input aria-label="输出版本名称" value={name} onChange={(e) => setName(e.target.value)} className="rounded border p-2" /></label><p className="text-sm">引擎：内置规则与 SimHash；来源许可未核验时仅形成候选，不自动发布。</p>{!validated && <p>请返回数据源页面验证当前文件。</p>}{error && <p role="alert">{error}</p>}<button disabled={!validated || busy} onClick={submit} className="rounded bg-blue-700 px-4 py-2 text-white disabled:opacity-50">启动处理任务</button></section>;
}
