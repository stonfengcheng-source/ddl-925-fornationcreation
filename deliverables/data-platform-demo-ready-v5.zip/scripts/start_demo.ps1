param([string]$Python = 'python', [int]$ApiPort = 8000, [int]$WebPort = 5173, [string]$DemoDir = '')
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$demoDir = if ($DemoDir) { [System.IO.Path]::GetFullPath($DemoDir) } else { Join-Path $project 'data/preproject/demo' }
$pidFile = Join-Path $demoDir 'processes.json'
if (Test-Path -LiteralPath $pidFile) { throw '已有演示进程记录。请先运行 scripts/stop_demo.ps1。' }
$pythonCmd = (Get-Command $Python -ErrorAction Stop).Source
$nodeCmd = (Get-Command node -ErrorAction Stop).Source
$vite = Join-Path $project 'frontend/node_modules/vite/bin/vite.js'
if (-not (Test-Path -LiteralPath $vite)) { throw '缺少前端依赖，请先在 frontend 运行 npm ci。' }
& $pythonCmd -c 'import fastapi, uvicorn, sqlalchemy, multipart, httpx' 2>$null
if ($LASTEXITCODE -ne 0) { throw '缺少后端依赖，请先安装 backend/requirements.txt。' }
New-Item -ItemType Directory -Force -Path $demoDir | Out-Null
$env:AUTH_MODE = 'passwordless'
$env:APP_ENV = 'development'
$env:DEV_AUTH_USERNAME = 'admin'
$env:PLATFORM_DEMO_MODE = '1'
$env:DATABASE_URL = 'sqlite:///' + ((Join-Path $demoDir 'demo.db') -replace '\\','/')
$env:PREPROJECT_DATA_DIR = Join-Path $demoDir 'storage'
$env:VITE_API_PROXY_TARGET = "http://127.0.0.1:$ApiPort"
$backend = $null; $frontend = $null
try {
  $backend = Start-Process -FilePath $pythonCmd -ArgumentList @('-m','uvicorn','app.main:app','--host','127.0.0.1','--port',"$ApiPort") -WorkingDirectory (Join-Path $project 'backend') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $demoDir 'backend.out.log') -RedirectStandardError (Join-Path $demoDir 'backend.err.log')
  $frontend = Start-Process -FilePath $nodeCmd -ArgumentList @($vite,'--host','127.0.0.1','--port',"$WebPort",'--strictPort') -WorkingDirectory (Join-Path $project 'frontend') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $demoDir 'frontend.out.log') -RedirectStandardError (Join-Path $demoDir 'frontend.err.log')
  @{ backend = @{ id=$backend.Id; started=$backend.StartTime.ToUniversalTime().Ticks; path=$backend.Path }; frontend = @{ id=$frontend.Id; started=$frontend.StartTime.ToUniversalTime().Ticks; path=$frontend.Path } } | ConvertTo-Json | Set-Content -LiteralPath $pidFile -Encoding UTF8
  $ready = $false
  for ($i=0; $i -lt 40; $i++) {
    try { & (Join-Path $PSScriptRoot 'smoke_test.ps1') -ApiPort $ApiPort -WebPort $WebPort -Quiet; $ready = $true; break } catch { Start-Sleep -Milliseconds 500 }
  }
  if (-not $ready) { throw '服务未就绪，请检查 data/preproject/demo 下的日志。' }
  try { $bootstrap = Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$ApiPort/api/preproject-data/examples/bootstrap" -TimeoutSec 30 } catch { throw "演示示例初始化失败，请检查文件完整性和后端日志：$($_.Exception.Message)" }
  if (-not $bootstrap.ready -or -not $bootstrap.source.source_id) { throw '默认示例初始化未完成。' }
  $demoStatus = Invoke-RestMethod -Uri "http://127.0.0.1:$ApiPort/api/preproject-data/examples/default" -TimeoutSec 30
  if (-not $demoStatus.ready -or $demoStatus.source.source_id -ne $bootstrap.source.source_id) { throw '默认示例验证失败，演示尚未就绪。' }
  Write-Output "前端：http://127.0.0.1:$WebPort/app/dashboard"
  Write-Output "后端：http://127.0.0.1:$ApiPort/health"
  Write-Output '首次访问请在登录页输入 admin，本地演示模式无需密码。'
  Write-Output '默认合成示例及教育问答模板已准备；登录后点击“体验完整数据治理流程”。'
} catch {
  if ($frontend -and -not $frontend.HasExited) { Stop-Process -Id $frontend.Id -Force }
  if ($backend -and -not $backend.HasExited) { Stop-Process -Id $backend.Id -Force }
  if (Test-Path -LiteralPath $pidFile) { Remove-Item -LiteralPath $pidFile }
  throw
}
