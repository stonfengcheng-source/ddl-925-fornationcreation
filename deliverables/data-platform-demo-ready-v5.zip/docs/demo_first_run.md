# 默认演示首次运行

在 Windows 安装基础后端依赖 `python -m pip install -r backend/requirements.txt`，并在 `frontend` 运行 `npm ci`。项目根目录运行 `scripts/start_demo.ps1`；使用工作台地址、admin 本地免密登录。启动脚本使用本机地址、独立演示数据库和存储，并调用明确的初始化操作校验及登记平台示例；初始化失败会报告错误。生产环境不会自动创建示例。

点击“体验完整数据治理流程”，任务运行后自动进入质量分析。示例为合成数据，不需要训练依赖、GPU、网络、用户上传或填写路径。停止使用 `scripts/stop_demo.ps1`；重启复用已登记示例。已有任务可继续查看，也可明确选择重新运行。
