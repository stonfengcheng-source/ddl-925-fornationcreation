import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert, Button, Card, Col, Row, Space, Statistic, Typography } from 'antd';
import { createExampleGovernanceTask, getDefaultExample, type PreprojectTask } from '@/services/api/preprojectData';
import request from '@/services/request';

export default function ProductStart() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [lastDemo, setLastDemo] = useState<PreprojectTask | null>(null);
  const [demoReady, setDemoReady] = useState(false);
  const [summary, setSummary] = useState<{asset_count: number; running_tasks: number; pending_reviews: number | null; qualified_versions: number; experiment_count: number | null; training_ready: boolean; recent_tasks: Array<{task_id: string; source_id: string; status: string; processed: number; total: number}>} | null>(null);
  useEffect(() => {
    let active = true;
    getDefaultExample().then(value => { if (active) { setDemoReady(value.ready); setLastDemo(value.task); } }).catch(() => undefined);
    request.get('/preproject-data/overview').then((value) => { if (active) setSummary(value as unknown as NonNullable<typeof summary>); })
      .catch(() => { if (active) setError('数据建设概览暂不可用，请检查连接后重试。'); });
    return () => { active = false; };
  }, []);
  async function startExample(rerun = false) {
    setBusy(true); setError('');
    try {
      const result = await createExampleGovernanceTask(rerun);
      const target = result.task.status === 'completed' ? 'quality' : 'tasks';
      navigate(`/app/data-governance/${target}?source_id=${encodeURIComponent(result.source.source_id)}&task_id=${encodeURIComponent(result.task.task_id)}${target === 'tasks' ? '&auto_result=1' : ''}`);
    } catch { setError('示例任务创建失败，请确认服务及内置示例可用后重试。'); }
    finally { setBusy(false); }
  }
  const steps = [
    ['选择数据', '/app/data-governance/sources'], ['数据治理', '/app/data-governance/pipelines'],
    ['质量评价', '/app/data-governance/quality'], ['版本交付', '/app/data-governance/versions'],
    ['训练实验', '/app/model-experiments'], ['效果分析', '/app/model-experiments'],
  ];
  return <section style={{marginBottom: 24}}>
    <Card title={<Typography.Title level={3} style={{margin: 0}}>开始使用数鉴</Typography.Title>}>
      <Typography.Paragraph type="secondary">使用平台内置示例，体验数据清洗、去重、隐私保护、质量评价和版本交付。</Typography.Paragraph>
      <Space wrap><Button type="primary" size="large" loading={busy} onClick={() => void startExample()}>{lastDemo?.status === 'completed' ? '继续上次演示' : '体验完整数据治理流程'}</Button>
        {lastDemo && <Button onClick={() => void startExample(true)} loading={busy}>重新运行示例</Button>}
        <Button onClick={() => navigate('/app/data-assets')}>查看我的数据资产</Button>
        <Button onClick={() => navigate('/app/data-governance/sources')}>导入新数据</Button></Space>
      <Typography.Paragraph type="secondary" style={{marginTop: 10}}>平台示例数据 · 合成数据 · 用于功能体验 {demoReady ? '· 已准备' : '· 启动演示服务后自动准备'}</Typography.Paragraph>
      {error && <Alert type="warning" showIcon message={error} />}
      <Row gutter={[12,12]} style={{marginTop: 8}}>
        <Col xs={12} md={4}><Statistic title="数据资产" value={summary?.asset_count ?? '—'} /></Col>
        <Col xs={12} md={4}><Statistic title="运行中的治理任务" value={summary?.running_tasks ?? '—'} /></Col>
        <Col xs={12} md={4}><Statistic title="待人工复核" value={summary?.pending_reviews ?? '—'} /></Col>
        <Col xs={12} md={4}><Statistic title="合格候选版本" value={summary?.qualified_versions ?? '—'} /></Col>
        <Col xs={12} md={4}><Statistic title="训练实验" value={summary?.experiment_count ?? '—'} /></Col>
        <Col xs={12} md={4}><Typography.Text type="secondary">训练资源</Typography.Text><div>{summary ? summary.training_ready ? '已就绪' : '训练能力待配置' : '正在读取'}</div></Col>
      </Row>
    </Card>
    <Row gutter={[12,12]} style={{marginTop: 12}}>{steps.map(([label, href], index) => <Col key={label} xs={12} md={8} xl={4}><Card size="small" hoverable onClick={() => navigate(href)}><Typography.Text type="secondary">0{index + 1}</Typography.Text><div>{label} →</div></Card></Col>)}</Row>
    <Card title="最近数据治理任务" style={{marginTop: 12}} extra={<Button type="link" onClick={() => navigate('/app/data-governance/tasks')}>查看全部</Button>}>
      {summary?.recent_tasks.length ? summary.recent_tasks.map(task => <p key={task.task_id}><Button type="link" onClick={() => navigate(`/app/data-governance/tasks?source_id=${encodeURIComponent(task.source_id)}&task_id=${encodeURIComponent(task.task_id)}`)}>{task.status} · {task.processed}/{task.total} 条</Button></p>) : <Typography.Text type="secondary">{summary ? '还没有治理任务，可先创建示例任务。' : '正在读取任务。'}</Typography.Text>}
    </Card>
  </section>;
}
