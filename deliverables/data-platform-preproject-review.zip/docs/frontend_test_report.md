# 前端测试和演示

测试命令：`cd frontend; npm ci; npm test; npm run build`。构建包含 TypeScript 检查。页面相关组件测试使用 API 桩验证交互，不等于真实浏览器操作；真实 API 运行结果另见 `real_data_test_report.md`。本轮未使用浏览器，也没有伪造截图。

本轮全量 Vitest：13 个文件、48 项通过。此前两项排序测试超时的主要开销是多次对复杂表格执行角色查询；改为在目标表格中读取行单元格后通过，并限制测试工作进程为 2，未扩大超时。构建和 TypeScript 检查通过，存在动态导入混用与大 chunk 警告。真实 HTTP 与 CLI 的详细范围见对应报告；后端登录 pytest 在当前环境启动后未结束，已中断，不能作为通过项。

演示脚本为 `scripts/start_demo.ps1`、`scripts/smoke_test.ps1` 和 `scripts/stop_demo.ps1`。默认使用隔离 SQLite、隔离存储及本机免密开发账号，只适合本机演示。离线数据 `demo-datasets/preproject-test-only.jsonl` 明确标记 TEST-ONLY；真实数据需手动上传，页面不会自动伪造或回退到模拟统计。

ZIP 已解压到新目录；流水线测试 13 项通过。解压目录离线安装因缺少 npm 缓存而失败，联网 `npm ci --ignore-scripts` 后成功安装；使用已有 Python 环境在解压目录启动前后端、健康检查并停止均通过。Python 依赖在该次检查中复用已有环境，未验证全新 Python 环境安装。
