# 预立项 API 约定

前缀 `/api/preproject-data`；使用现有认证，操作角色为 buyer/admin。真实服务的 `/openapi.json` 为参数和响应结构的权威来源。

`GET /catalog`、`GET /sources`、`POST /sources/upload`、`POST /sources/{id}/validate`、`GET /sources/{id}/preview` 完成数据源管理。`POST /tasks` 提交配置；`GET /tasks/{id}` 返回真实状态和日志；`POST /tasks/{id}/cancel` 和 `/retry` 控制任务。`GET /tasks/{id}/results` 返回统计、质量、准入及实际可下载文件。`GET /tasks/{id}/samples` 提供脱敏前后对照；`GET /tasks/{id}/review-items`、`POST /tasks/{id}/reviews` 和 `GET /tasks/{id}/reviews` 处理审核；`GET /versions` 和 `GET /version-comparison?left=...&right=...` 查询版本及样本差异。文件通过 `GET /tasks/{id}/files/{filename}` 下载；不存在或不在白名单的文件返回 404。发布候选需来源、许可和授权均核验，否则返回 409。

对于 raw 版本，当前比较仅有样本 ID，无法从该接口可靠得出内容变化，返回 null 和原因。应用实际响应应以运行中的 OpenAPI 及接口为准。
