import request from '@/services/request';

export interface PreprojectSource {
  source_id: string;
  dataset_id: string;
  source_url: string;
  license: string;
  revision: string;
  split: string;
  sample_count: number;
  file_sha256: string;
  file_size_bytes: number;
  field_names: string[];
  acquired_at: string;
  revision_verified: boolean;
  license_verified: boolean;
  source_type?: string;
  license_verification_status?: string;
  revision_verification_status?: string;
  version_id?: string;
  status?: string;
  raw_file_path?: string;
}

export interface PreprojectTask {
  task_id: string;
  source_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  current_step: string;
  processed: number;
  total: number;
  created_at: string;
  started_at?: string | null;
  ended_at?: string | null;
  error?: string | null;
  statistics?: Record<string, any>;
  quality?: Record<string, any>;
  gate?: Record<string, any>;
  version_id?: string;
  reviewed_version_id?: string;
  logs?: Array<{ stage: string; processed?: number; total?: number; time?: string }>;
}

export interface PreprojectReviewItem {
  sample_id: string;
  status: string;
  reasons: string[];
  decision: string;
  preview?: Record<string, string>;
}

export interface PreprojectVersion {
  version_id: string;
  parent_version_id?: string | null;
  version_type: string;
  sample_count: number;
  status: string;
  authorization_status?: string;
  revision_verification_status?: string;
  license_verification_status?: string;
  created_at: string;
}

const base = '/preproject-data';

export const getPreprojectCatalog = () => request.get(`${base}/catalog`) as Promise<{ items: any[] }>;
export const startPreprojectFetch = (count: 200 | 5000) =>
  request.post(`${base}/sources/fetch`, { count }) as Promise<{ fetch_id: string; status: string; total: number }>;
export const getPreprojectFetch = (fetchId: string) =>
  request.get(`${base}/sources/fetch/${fetchId}`) as Promise<any>;
export const listPreprojectSources = () => request.get(`${base}/sources`) as Promise<{ items: PreprojectSource[] }>;
export const listPreprojectTasks = () => request.get(`${base}/tasks`) as Promise<{ items: PreprojectTask[] }>;

export async function uploadPreprojectSource(file: File, metadata: {
  dataset_id: string;
  source_url: string;
  license: string;
  revision: string;
  split: string;
}): Promise<PreprojectSource> {
  const form = new FormData();
  form.append('file', file);
  Object.entries(metadata).forEach(([key, value]) => form.append(key, value));
  return request.post(`${base}/sources/upload`, form, { headers: { 'Content-Type': undefined } }) as Promise<PreprojectSource>;
}

export const validatePreprojectSource = (sourceId: string) =>
  request.post(`${base}/sources/${sourceId}/validate`) as Promise<Record<string, any>>;
export const previewPreprojectSource = (sourceId: string, offset = 0, limit = 10) =>
  request.get(`${base}/sources/${sourceId}/preview`, { params: { offset, limit } }) as Promise<{ samples: any[]; total: number }>;
export const listPreprojectVersions = () => request.get(`${base}/versions`) as Promise<{ items: PreprojectVersion[]; total: number }>;
export const comparePreprojectVersions = (left: string, right: string) => request.get(`${base}/version-comparison`, { params: { left, right } }) as Promise<any>;
export const getPreprojectSamples = (taskId: string, offset = 0, issue = '') => request.get(`${base}/tasks/${taskId}/samples`, { params: { offset, limit: 10, issue: issue || undefined } }) as Promise<any>;
export const createPreprojectReleaseCandidate = (versionId: string) =>
  request.post(`${base}/versions/${encodeURIComponent(versionId)}/release-candidate`) as Promise<{ version: PreprojectVersion }>;

export const createPreprojectTask = (payload: {
  source_id: string;
  cleaning_enabled: boolean;
  near_duplicate_enabled: boolean;
  near_duplicate_hamming_distance: number;
  near_duplicate_action: 'review_only';
  privacy_enabled: true;
  version_name: string;
}) => request.post(`${base}/tasks`, payload) as Promise<{ task: PreprojectTask; duplicate_submission: boolean }>;

export const getPreprojectTask = (taskId: string) =>
  request.get(`${base}/tasks/${taskId}`) as Promise<PreprojectTask>;
export const cancelPreprojectTask = (taskId: string) => request.post(`${base}/tasks/${taskId}/cancel`);
export const retryPreprojectTask = (taskId: string) =>
  request.post(`${base}/tasks/${taskId}/retry`) as Promise<{ task: PreprojectTask }>;
export const getPreprojectResults = (taskId: string) => request.get(`${base}/tasks/${taskId}/results`) as Promise<any>;
export const getPreprojectReviewItems = (taskId: string, offset = 0, limit = 20, issueType?: string) =>
  request.get(`${base}/tasks/${taskId}/review-items`, { params: { offset, limit, issue_type: issueType || undefined } }) as Promise<{ items: PreprojectReviewItem[]; total: number; pending_count: number }>;
export const getPreprojectReviewHistory = (taskId: string) =>
  request.get(`${base}/tasks/${taskId}/reviews`) as Promise<{ items: any[]; total: number }>;
export const submitPreprojectReview = (taskId: string, payload: {
  sample_id: string;
  decision: 'accept' | 'edit' | 'quarantine' | 'reject';
  issue_type?: string;
  edited_content?: Record<string, string>;
  notes?: string;
}) => request.post(`${base}/tasks/${taskId}/reviews`, payload) as Promise<any>;

export async function downloadPreprojectFile(taskId: string, filename: string): Promise<void> {
  const blob = await request.get(`${base}/tasks/${taskId}/files/${encodeURIComponent(filename)}`, {
    responseType: 'blob',
  }) as Blob;
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
