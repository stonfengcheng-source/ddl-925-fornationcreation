import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import PreprojectDataPage from './index';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { getPreprojectCatalog, getPreprojectFetch, listPreprojectSources, listPreprojectTasks, listPreprojectVersions, previewPreprojectSource, startPreprojectFetch } from '@/services/api/preprojectData';

vi.mock('@/services/api/preprojectData', () => ({
  getPreprojectCatalog: vi.fn(),
  getPreprojectFetch: vi.fn(),
  getPreprojectResults: vi.fn(),
  getPreprojectTask: vi.fn(),
  getPreprojectReviewHistory: vi.fn(),
  getPreprojectReviewItems: vi.fn(),
  listPreprojectSources: vi.fn(),
  listPreprojectTasks: vi.fn(),
  listPreprojectVersions: vi.fn(),
  previewPreprojectSource: vi.fn(),
  startPreprojectFetch: vi.fn(),
  uploadPreprojectSource: vi.fn(),
  validatePreprojectSource: vi.fn(),
  createPreprojectTask: vi.fn(),
  cancelPreprojectTask: vi.fn(),
  retryPreprojectTask: vi.fn(),
  submitPreprojectReview: vi.fn(),
  downloadPreprojectFile: vi.fn(),
}));

describe('Preproject data page', () => {
  const renderPage = () => render(<MemoryRouter initialEntries={['/app/preproject-data/sources']}><Routes><Route path="/app/preproject-data/:section?" element={<PreprojectDataPage />} /></Routes></MemoryRouter>);
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(getPreprojectCatalog).mockResolvedValue({ items: [{
      dataset_id: 'ecnu-icalk/educhat-sft-002-data-osm',
      source_url: 'https://huggingface.co/datasets/ecnu-icalk/educhat-sft-002-data-osm',
      license: 'cc-by-nc-4.0', revision: 'rev-1',
    }] });
    vi.mocked(listPreprojectSources).mockResolvedValue({ items: [] });
    vi.mocked(listPreprojectTasks).mockResolvedValue({ items: [] });
    vi.mocked(listPreprojectVersions).mockResolvedValue({ items: [], total: 0 });
    vi.mocked(previewPreprojectSource).mockResolvedValue({ samples: [], total: 0 });
    vi.mocked(startPreprojectFetch).mockResolvedValue({ fetch_id: 'fetch-1', status: 'pending', total: 200 });
    vi.mocked(getPreprojectFetch).mockResolvedValue({ fetch_id: 'fetch-1', status: 'failed', error: 'network blocked' });
  });

  it('loads the official catalog and starts the selected real fetch endpoint', async () => {
    renderPage();
    expect(await screen.findByText('ecnu-icalk/educhat-sft-002-data-osm')).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: '采集 200 条试运行' }));
    await waitFor(() => expect(startPreprojectFetch).toHaveBeenCalledWith(200));
    await waitFor(() => expect(getPreprojectFetch).toHaveBeenCalledWith('fetch-1'));
  });

  it('separates data sources, task execution, and reports without pre-labeling local files as EduChat', async () => {
    renderPage();
    expect(await screen.findByText('ecnu-icalk/educhat-sft-002-data-osm')).toBeTruthy();
    expect(screen.getByLabelText('数据集 ID')).toHaveValue('');
    expect(screen.getByLabelText('许可（未知请明确填写“未知”）')).toHaveValue('');

    fireEvent.click(screen.getByRole('button', { name: /处理配置/ }));
    expect(screen.getByRole('button', { name: '启动处理任务' })).toBeDisabled();
    fireEvent.click(screen.getByRole('button', { name: /任务执行/ }));
    expect(screen.getByRole('button', { name: /任务执行/ })).toHaveAttribute('aria-pressed', 'true');

    fireEvent.click(screen.getByRole('button', { name: '结果与报告' }));
    expect(screen.getByRole('button', { name: '结果与报告' })).toHaveAttribute('aria-pressed', 'true');
  });
});
