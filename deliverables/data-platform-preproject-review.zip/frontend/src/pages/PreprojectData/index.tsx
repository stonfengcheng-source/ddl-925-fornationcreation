import React from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  cancelPreprojectTask,
  comparePreprojectVersions,
  createPreprojectReleaseCandidate,
  createPreprojectTask,
  downloadPreprojectFile,
  getPreprojectFetch,
  getPreprojectCatalog,
  getPreprojectResults,
  getPreprojectSamples,
  getPreprojectReviewHistory,
  getPreprojectReviewItems,
  getPreprojectTask,
  listPreprojectVersions,
  listPreprojectSources,
  listPreprojectTasks,
  previewPreprojectSource,
  retryPreprojectTask,
  startPreprojectFetch,
  submitPreprojectReview,
  uploadPreprojectSource,
  validatePreprojectSource,
  type PreprojectSource,
  type PreprojectTask,
  type PreprojectReviewItem,
  type PreprojectVersion,
} from '@/services/api/preprojectData';

const dimensionLabels: Record<string, string> = {
  completeness: '完整性',
  consistency: '一致性',
  diversity: '多元性',
  unbiasedness: '无偏性',
  timeliness: '时效性',
};

const statusLabels: Record<string, string> = {
  pending: '等待中', running: '处理中', completed: '已完成', failed: '失败', cancelled: '已取消',
};
const stageLabels: Record<string, string> = {
  queued: '排队中', starting: '启动中', processing: '处理中', schema_and_cleaning: '格式整理与清洗',
  deduplication: '去重检查', privacy: '敏感信息检测与脱敏', quality_report: '五维质量评价',
  completed: '处理完成', failed: '处理失败', cancelled: '已取消', interrupted: '进程中断',
};

function errorMessage(error: any): string {
  const detail = error?.response?.data?.detail;
  if (typeof detail === 'string') return detail;
  if (detail && typeof detail === 'object') return [detail.message, ...(detail.reasons || [])].filter(Boolean).join('；');
  return error?.message || '请求失败，请检查后端服务状态';
}

function valueText(value: unknown): string {
  if (value === null || value === undefined || value === 'N/A') return 'N/A';
  if (typeof value === 'number') return value <= 1 ? `${(value * 100).toFixed(2)}%` : value.toLocaleString();
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

function runtimeText(task: PreprojectTask): string {
  if (!task.started_at) return '尚未开始';
  const started = new Date(task.started_at).getTime();
  const ended = task.ended_at ? new Date(task.ended_at).getTime() : Date.now();
  const seconds = Math.max(0, Math.floor((ended - started) / 1000));
  return `${Math.floor(seconds / 60)} 分 ${seconds % 60} 秒`;
}

const PreprojectDataPage: React.FC = () => {
  const navigate = useNavigate();
  const { section = 'sources' } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const panelFromRoute: Record<string, string> = { sources: 'sources', pipelines: 'pipelines', tasks: 'tasks', quality: 'results', reviews: 'review', versions: 'versions' };
  const routeFromPanel: Record<string, string> = { sources: 'sources', pipelines: 'pipelines', tasks: 'tasks', results: 'quality', review: 'reviews', versions: 'versions' };
  const activePanel = panelFromRoute[section] || 'sources';
  const setActivePanel = (panel: string) => navigate(`/app/preproject-data/${routeFromPanel[panel] || 'sources'}${searchParams.toString() ? `?${searchParams}` : ''}`);
  const selectedSource = searchParams.get('source_id') || '';
  const selectedTask = searchParams.get('task_id') || '';
  const setContext = (key: string, value: string) => setSearchParams((current) => {
    const next = new URLSearchParams(current);
    if (value) next.set(key, value); else next.delete(key);
    return next;
  }, { replace: true });
  const setSelectedSource = (value: string) => {
    setPreviewOffset(0);
    setSearchParams((current) => { const next = new URLSearchParams(current); next.set('source_id', value); if (value !== current.get('source_id')) next.delete('task_id'); return next; }, { replace: true });
    setResults(null);
  };
  const setSelectedTask = (value: string) => setContext('task_id', value);
  const [catalog, setCatalog] = React.useState<any[]>([]);
  const [sources, setSources] = React.useState<PreprojectSource[]>([]);
  const [tasks, setTasks] = React.useState<PreprojectTask[]>([]);
  const [versions, setVersions] = React.useState<PreprojectVersion[]>([]);
  const [sourcePreview, setSourcePreview] = React.useState<any[]>([]);
  const [previewOffset, setPreviewOffset] = React.useState(0);
  const [sampleOffset, setSampleOffset] = React.useState(0);
  const [sampleIssue, setSampleIssue] = React.useState('');
  const [samples, setSamples] = React.useState<any>(null);
  const [leftVersion, setLeftVersion] = React.useState('');
  const [rightVersion, setRightVersion] = React.useState('');
  const [versionComparison, setVersionComparison] = React.useState<any>(null);
  const [reviewItems, setReviewItems] = React.useState<PreprojectReviewItem[]>([]);
  const [reviewHistory, setReviewHistory] = React.useState<any[]>([]);
  const [reviewFilter, setReviewFilter] = React.useState('');
  const [reviewOffset, setReviewOffset] = React.useState(0);
  const [reviewTotal, setReviewTotal] = React.useState(0);
  const [reviewPendingCount, setReviewPendingCount] = React.useState(0);
  const [selectedReviewId, setSelectedReviewId] = React.useState('');
  const [reviewDraft, setReviewDraft] = React.useState({ instruction: '', output: '', notes: '' });
  const [fetchId, setFetchId] = React.useState('');
  const [fetchStatus, setFetchStatus] = React.useState<any>(null);
  const [results, setResults] = React.useState<any>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState('');
  const [notice, setNotice] = React.useState('');
  const [file, setFile] = React.useState<File | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [metadata, setMetadata] = React.useState({
    dataset_id: '',
    source_url: '',
    license: '',
    revision: '',
    split: 'local',
  });
  const [cleaningEnabled, setCleaningEnabled] = React.useState(() => sessionStorage.getItem('pp-clean') !== 'false');
  const [nearDuplicateEnabled, setNearDuplicateEnabled] = React.useState(() => sessionStorage.getItem('pp-near') !== 'false');
  const [nearDuplicateDistance, setNearDuplicateDistance] = React.useState(() => Number(sessionStorage.getItem('pp-distance') ?? 3));
  const [versionName, setVersionName] = React.useState(() => sessionStorage.getItem('pp-version') || 'local-preproject-run');

  React.useEffect(() => {
    sessionStorage.setItem('pp-clean', String(cleaningEnabled));
    sessionStorage.setItem('pp-near', String(nearDuplicateEnabled));
    sessionStorage.setItem('pp-distance', String(nearDuplicateDistance));
    sessionStorage.setItem('pp-version', versionName);
  }, [cleaningEnabled, nearDuplicateEnabled, nearDuplicateDistance, versionName]);

  const refresh = React.useCallback(async () => {
    const [catalogResult, sourceResult, taskResult, versionResult] = await Promise.allSettled([
      getPreprojectCatalog(), listPreprojectSources(), listPreprojectTasks(), listPreprojectVersions(),
    ]);
    if (catalogResult.status === 'fulfilled') setCatalog(catalogResult.value.items || []);
    if (sourceResult.status === 'fulfilled') {
      setSources(sourceResult.value.items || []);
    }
    if (taskResult.status === 'fulfilled') setTasks(taskResult.value.items || []);
    if (versionResult.status === 'fulfilled') setVersions(versionResult.value.items || []);
    const failures = [catalogResult, sourceResult, taskResult, versionResult].filter((result) => result.status === 'rejected');
    if (failures.length) {
      const reason = failures[0].status === 'rejected' ? failures[0].reason : null;
      setError(`部分数据未能加载${failures.length > 1 ? `（${failures.length} 项）` : ''}：${errorMessage(reason)}`);
    } else {
      setError('');
    }
  }, []);

  React.useEffect(() => {
    refresh().catch((cause) => setError(errorMessage(cause)));
  }, [refresh]);

  React.useEffect(() => {
    if (!selectedSource) { setSourcePreview([]); return undefined; }
    let disposed = false;
    previewPreprojectSource(selectedSource, previewOffset, 5)
      .then((result) => { if (!disposed) setSourcePreview(result.samples || []); })
      .catch((cause) => { if (!disposed) setError(errorMessage(cause)); });
    return () => { disposed = true; };
  }, [selectedSource, previewOffset]);

  React.useEffect(() => {
    if (!selectedTask || activePanel !== 'results' || !results) return undefined;
    let disposed = false;
    getPreprojectSamples(selectedTask, sampleOffset, sampleIssue).then((data) => { if (!disposed) setSamples(data); })
      .catch((cause) => { if (!disposed) setError(errorMessage(cause)); });
    return () => { disposed = true; };
  }, [selectedTask, activePanel, sampleOffset, sampleIssue, results]);

  React.useEffect(() => {
    if (!selectedTask) return undefined;
    let disposed = false;
    let timer: number | undefined;
    const update = async () => {
      try {
        const task = await getPreprojectTask(selectedTask);
        if (disposed) return;
        setTasks((current) => [task, ...current.filter((item) => item.task_id !== task.task_id)]);
        if (task.status === 'completed') {
          const [nextResults, reviews, history, versionList] = await Promise.all([
            getPreprojectResults(selectedTask), getPreprojectReviewItems(selectedTask),
            getPreprojectReviewHistory(selectedTask), listPreprojectVersions(),
          ]);
          if (!disposed) {
            setResults(nextResults);
            setReviewItems(reviews.items || []);
            setReviewTotal(reviews.total || 0);
            setReviewPendingCount(reviews.pending_count || 0);
            setReviewHistory(history.items || []);
            setVersions(versionList.items || []);
          }
        }
        if (!['completed', 'failed', 'cancelled'].includes(task.status) && !disposed) timer = window.setTimeout(update, 2000);
      } catch (cause) {
        if (!disposed) setError(errorMessage(cause));
      }
    };
    void update();
    return () => { disposed = true; window.clearTimeout(timer); };
  }, [selectedTask]);

  React.useEffect(() => {
    if (!selectedTask || activePanel !== 'review') return undefined;
    let disposed = false;
    Promise.all([
      getPreprojectReviewItems(selectedTask, reviewOffset, 20, reviewFilter || undefined),
      getPreprojectReviewHistory(selectedTask),
    ]).then(([queue, history]) => {
      if (disposed) return;
      setReviewItems(queue.items || []); setReviewTotal(queue.total || 0);
      setReviewPendingCount(queue.pending_count || 0); setReviewHistory(history.items || []);
    }).catch((cause) => { if (!disposed) setError(errorMessage(cause)); });
    return () => { disposed = true; };
  }, [selectedTask, activePanel, reviewFilter, reviewOffset]);

  React.useEffect(() => {
    if (!fetchId) return undefined;
    let disposed = false;
    const update = async () => {
      try {
        const status = await getPreprojectFetch(fetchId);
        if (disposed) return;
        setFetchStatus(status);
        if (status.status === 'completed') {
          const [sourceResponse] = await Promise.all([listPreprojectSources()]);
          if (!disposed) {
            setSources(sourceResponse.items || []);
            setSelectedSource(status.source_id);
            setNotice(`官方采集完成：${status.sample_count} 条；来源清单已保存。`);
            setFetchId('');
          }
        } else if (status.status === 'failed') {
          setError(status.error || '官方数据采集失败');
          setFetchId('');
        }
      } catch (cause) {
        if (!disposed) { setError(errorMessage(cause)); setFetchId(''); }
      }
    };
    void update();
    const timer = window.setInterval(() => void update(), 2000);
    return () => { disposed = true; window.clearInterval(timer); };
  }, [fetchId]);

  const activeTask = tasks.find((item) => item.task_id === selectedTask);
  const selectedReview = reviewItems.find((item) => item.sample_id === selectedReviewId) || reviewItems[0];

  React.useEffect(() => {
    if (!selectedReview) { setSelectedReviewId(''); return; }
    setSelectedReviewId(selectedReview.sample_id);
    setReviewDraft({ instruction: selectedReview.preview?.instruction || '', output: selectedReview.preview?.output || '', notes: '' });
  }, [selectedReview?.sample_id]);

  const handleReview = async (decision: 'accept' | 'edit' | 'quarantine' | 'reject') => {
    if (!selectedTask || !selectedReview) return;
    setBusy(true); setError(''); setNotice('');
    try {
      const result = await submitPreprojectReview(selectedTask, {
        sample_id: selectedReview.sample_id,
        issue_type: reviewFilter || selectedReview.reasons?.[0] || '',
        decision,
        edited_content: decision === 'edit' ? { instruction: reviewDraft.instruction, output: reviewDraft.output } : undefined,
        notes: reviewDraft.notes,
      });
      const [queue, history, versionList, nextResults] = await Promise.all([
        getPreprojectReviewItems(selectedTask, reviewOffset, 20, reviewFilter || undefined),
        getPreprojectReviewHistory(selectedTask), listPreprojectVersions(), getPreprojectResults(selectedTask),
      ]);
      setReviewItems(queue.items || []); setReviewHistory(history.items || []);
      setReviewTotal(queue.total || 0); setReviewPendingCount(queue.pending_count || 0);
      setVersions(versionList.items || []); setResults(nextResults);
      setNotice(`复核已保存并重新质检，生成版本 ${result.version?.version_id || ''}`);
    } catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  const handleReleaseCandidate = async (versionId: string) => {
    setBusy(true); setError(''); setNotice('');
    try {
      await createPreprojectReleaseCandidate(versionId);
      const next = await listPreprojectVersions(); setVersions(next.items || []);
      setNotice('发布候选版本已生成');
    } catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  const handleUpload = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!file) { setError('请先选择 JSONL、JSON 或 Parquet 文件'); return; }
    if (file.size > 100 * 1024 * 1024) { setError('文件超过 100 MiB 上传限制'); return; }
    if (!['.jsonl', '.json', '.parquet', '.pq'].includes(file.name.slice(file.name.lastIndexOf('.')).toLowerCase())) {
      setError('仅支持 JSONL、JSON 或 Parquet 文件'); return;
    }
    if (!metadata.dataset_id.trim() || !metadata.license.trim() || !metadata.revision.trim()) {
      setError('请填写数据集标识、许可和版本；未知信息请明确填写“未知”'); return;
    }
    setBusy(true); setError(''); setNotice('');
    try {
      const source = await uploadPreprojectSource(file, metadata);
      setSources((current) => [source, ...current]);
      setSelectedSource(source.source_id);
      setNotice(`导入成功：${source.sample_count} 条记录；文件哈希已随来源清单保存。`);
      setFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  const handleOfficialFetch = async (count: 200 | 5000) => {
    setBusy(true); setError(''); setNotice(''); setFetchStatus(null);
    try {
      const job = await startPreprojectFetch(count);
      setFetchId(job.fetch_id);
      setFetchStatus(job);
      setNotice(`已提交官方 ${count} 条样本采集任务；页面会自动轮询状态`);
    } catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  const handleValidate = async () => {
    if (!selectedSource) return;
    setBusy(true); setError(''); setNotice('');
    try {
      const result = await validatePreprojectSource(selectedSource);
      setNotice(result.message || (result.valid ? '文件结构和哈希通过' : '文件验证未通过'));
    } catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  const handleCreateTask = async () => {
    if (!selectedSource) { setError('请先导入并选择数据源'); return; }
    if (!versionName.trim()) { setError('请填写输出版本名称'); return; }
    if (!Number.isInteger(nearDuplicateDistance) || nearDuplicateDistance < 0 || nearDuplicateDistance > 64) {
      setError('近似重复阈值必须是 0 到 64 之间的整数'); return;
    }
    setBusy(true); setError(''); setNotice(''); setResults(null);
    try {
      const response = await createPreprojectTask({
        source_id: selectedSource,
        cleaning_enabled: cleaningEnabled,
        near_duplicate_enabled: nearDuplicateEnabled,
        near_duplicate_hamming_distance: nearDuplicateDistance,
        near_duplicate_action: 'review_only',
        privacy_enabled: true,
        version_name: versionName,
      });
      const nextContext = new URLSearchParams(searchParams);
      nextContext.set('source_id', selectedSource);
      nextContext.set('task_id', response.task.task_id);
      setTasks((current) => [response.task, ...current.filter((item) => item.task_id !== response.task.task_id)]);
      navigate(`/app/preproject-data/tasks?${nextContext.toString()}`);
      setNotice(response.duplicate_submission ? '已返回相同配置的运行中任务' : '任务已提交，正在等待后端处理');
    } catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  const handleCancel = async () => {
    if (!selectedTask) return;
    setBusy(true);
    try { await cancelPreprojectTask(selectedTask); setNotice('已请求取消任务'); }
    catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  const handleRetry = async () => {
    if (!selectedTask) return;
    setBusy(true);
    try {
      const response = await retryPreprojectTask(selectedTask);
      setSelectedTask(response.task.task_id);
      setTasks((current) => [response.task, ...current]);
      setResults(null);
      setNotice('重试任务已提交');
    } catch (cause) { setError(errorMessage(cause)); }
    finally { setBusy(false); }
  };

  return (
    <main className="mx-auto max-w-7xl space-y-6 p-6 text-text">
      <header>
        <h1 className="text-2xl font-semibold">预立项数据处理</h1>
        <p className="mt-1 text-sm text-text-secondary">登记数据来源、运行可追踪处理任务，并查看质量指标与结果报告。</p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5" aria-label="当前数据概览">
        {[
          ['数据集', sources.find((source) => source.source_id === (activeTask?.source_id || selectedSource))?.dataset_id || '尚未选择'],
          ['当前版本', activeTask?.version_id || '尚未生成'],
          ['样本规模', activeTask?.total ?? sources.find((source) => source.source_id === selectedSource)?.sample_count ?? 'N/A'],
          ['任务状态', activeTask ? statusLabels[activeTask.status] || activeTask.status : '尚未选择'],
          ['合格 / 来源核验', results ? `${results.statistics?.final_retained_count ?? 'N/A'} / ${results.gate?.release_eligible ? '允许发布' : '未获发布授权'}` : 'N/A'],
        ].map(([label, value]) => <div key={String(label)} className="min-w-0 rounded-lg border border-border-light bg-white p-3"><div className="text-xs text-text-secondary">{label}</div><div className="mt-1 truncate text-sm font-medium" title={String(value)}>{value}</div></div>)}
      </div>

      {error && <div role="alert" className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>}
      {notice && <div role="status" className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">{notice}</div>}

      <nav aria-label="预立项数据处理功能" className="flex flex-wrap gap-2 border-b border-border-light pb-3">
        {[
          ['sources', `数据源管理 · ${sources.length}`],
          ['pipelines', '处理配置'],
          ['tasks', `任务执行 · ${tasks.length}`],
          ['results', '结果与报告'],
          ['review', `人工复核 · ${reviewPendingCount}`],
          ['versions', `数据版本 · ${versions.length}`],
        ].map(([key, label]) => <button key={key} type="button" aria-pressed={activePanel === key}
          onClick={() => setActivePanel(key)}
          className={`rounded-md px-4 py-2 text-sm ${activePanel === key ? 'bg-text-primary text-white' : 'border border-border-light bg-white'}`}>
          {label}
        </button>)}
      </nav>

      <section hidden={activePanel !== 'sources'} className="rounded-xl border border-border-light bg-white p-5">
        <h2 className="text-lg font-medium">官方数据源目录</h2>
        {catalog.map((item) => <div key={item.dataset_id} className="mt-3 rounded-lg bg-background-secondary p-4 text-sm">
          <div className="font-medium">{item.dataset_id}</div>
          <a className="text-blue-700 underline" href={item.source_url} target="_blank" rel="noreferrer">查看 Hugging Face 官方页面</a>
          <div className="mt-2 text-text-secondary">许可：{item.license} · 配置 Revision：{item.revision}</div>
          <div className="mt-1 text-amber-700">本机官方数据接口尚未验证；上传文件的版本和许可由导入者声明。</div>
          <div className="mt-1 text-text-secondary">字段：sequence（问答序列）、system_prompt（系统提示）</div>
          <div className="mt-3 flex gap-2">
            <button type="button" onClick={() => handleOfficialFetch(200)} disabled={busy || Boolean(fetchId)} className="rounded-md border border-border-light px-3 py-2 text-sm disabled:opacity-50">采集 200 条试运行</button>
            <button type="button" onClick={() => handleOfficialFetch(5000)} disabled={busy || Boolean(fetchId)} className="rounded-md border border-border-light px-3 py-2 text-sm disabled:opacity-50">采集 5,000 条主实验</button>
          </div>
          {fetchStatus && <div className="mt-2 text-xs text-text-secondary">采集状态：{fetchStatus.status} · {fetchStatus.current_step}</div>}
        </div>)}
      </section>

      <section className={`grid gap-5 ${activePanel === 'sources' ? 'lg:grid-cols-2' : 'grid-cols-1'}`}>
        <form hidden={activePanel !== 'sources'} onSubmit={handleUpload} className="space-y-4 rounded-xl border border-border-light bg-white p-5">
          <div><h2 className="text-lg font-medium">导入本地数据</h2><p className="mt-1 text-sm text-text-secondary">支持 JSONL、JSON 和 Parquet，最大 100 MiB。</p></div>
          <label className="block text-sm">数据文件
            <input ref={fileInputRef} type="file" accept=".jsonl,.json,.parquet,.pq" onChange={(event) => setFile(event.target.files?.[0] || null)} className="mt-1 block w-full text-sm" />
          </label>
          {(['dataset_id', 'source_url', 'license', 'revision', 'split'] as const).map((field) => (
            <label key={field} className="block text-sm">{({
              dataset_id: '数据集 ID', source_url: '来源链接（无链接请填写“本地文件”）',
              license: '许可（未知请明确填写“未知”）', revision: '版本（未知请明确填写“未知”）', split: 'Split / 文件分片',
            })[field]}
              <input value={metadata[field]} onChange={(event) => setMetadata((current) => ({ ...current, [field]: event.target.value }))}
                className="mt-1 w-full rounded-md border border-border-light px-3 py-2" required />
            </label>
          ))}
          <p className="text-xs text-amber-700">信息不会预填为 EduChat。导入后会记录文件哈希；手动填写的来源、许可和版本只作为用户声明。</p>
          <button type="submit" disabled={busy || !file} className="rounded-md bg-text-primary px-4 py-2 text-sm font-medium text-white disabled:opacity-50">{busy ? '处理中…' : '上传并校验文件'}</button>
        </form>

        <section hidden={activePanel !== 'sources'} className="space-y-4 rounded-xl border border-border-light bg-white p-5">
          <div><h2 className="text-lg font-medium">已导入数据源</h2><p className="mt-1 text-sm text-text-secondary">先选中并核验数据源，再进入任务执行。</p></div>
          <div className="space-y-2">
            {sources.map((source) => <button key={source.source_id} type="button" onClick={() => setSelectedSource(source.source_id)}
              className={`w-full rounded-lg border p-3 text-left ${source.source_id === selectedSource ? 'border-blue-500 bg-blue-50' : 'border-border-light'}`}>
              <div className="truncate font-medium">{source.dataset_id}</div>
              <div className="mt-1 break-all text-xs text-text-secondary">{source.sample_count} 条 · Raw版本 {source.version_id || '已登记'}</div>
              <div className="mt-1 text-xs">{source.revision_verified && source.license_verified ? '官方信息已核验' : '来源 / 许可为用户声明，尚未核验'}</div>
            </button>)}
            {!sources.length && <p className="text-sm text-text-secondary">暂无已导入数据源。请导入本地文件或提交官方采集任务。</p>}
          </div>
          {selectedSource && <div className="flex flex-wrap gap-2 border-t border-border-light pt-4">
            <button onClick={handleValidate} disabled={busy} className="rounded-md border border-border-light px-3 py-2 text-sm disabled:opacity-50">验证选中数据源</button>
            <button onClick={() => setActivePanel('pipelines')} className="rounded-md bg-blue-700 px-3 py-2 text-sm text-white">选择数据并开始处理</button>
          </div>}
          {selectedSource && <div className="border-t border-border-light pt-4">
            <h3 className="font-medium">脱敏样本预览</h3>
            <p className="mt-1 text-xs text-text-secondary">经当前规则清洗和脱敏后返回。</p>
            <div className="mt-3 space-y-3">{sourcePreview.map((sample) => <article key={sample.sample_id} className="rounded-md bg-background-secondary p-3 text-sm">
              <div className="text-xs text-text-secondary">{sample.sample_id} · 原始行 {sample.source_record_id}</div>
              <div className="mt-2 whitespace-pre-wrap"><b>问题：</b>{sample.instruction}</div>
              <div className="mt-1 whitespace-pre-wrap"><b>答案：</b>{sample.output}</div>
              {sample.input && <div className="mt-1 whitespace-pre-wrap text-xs text-text-secondary"><b>历史：</b>{sample.input}</div>}
            </article>)}
              {!sourcePreview.length && <p className="text-sm text-text-secondary">暂无可预览样本。</p>}
            </div>
            <div className="mt-3 flex gap-3 text-sm"><button disabled={previewOffset === 0} onClick={() => setPreviewOffset(Math.max(0, previewOffset - 5))}>上一页</button><span>第 {previewOffset + 1} 条起</span><button disabled={sourcePreview.length < 5 || previewOffset + 5 >= (sources.find((s) => s.source_id === selectedSource)?.sample_count || 0)} onClick={() => setPreviewOffset(previewOffset + 5)}>下一页</button></div>
          </div>}
        </section>

        <section hidden={activePanel !== 'pipelines'} className="space-y-4 rounded-xl border border-border-light bg-white p-5">
          <div><h2 className="text-lg font-medium">数据源与任务设置</h2><p className="mt-1 text-sm text-text-secondary">隐私检测和脱敏为必开项，近似重复仅标记待复核。</p></div>
          <label className="block text-sm">数据源
            <select value={selectedSource} onChange={(event) => setSelectedSource(event.target.value)} className="mt-1 w-full rounded-md border border-border-light px-3 py-2">
              <option value="">请选择已导入数据</option>
              {sources.map((source) => <option key={source.source_id} value={source.source_id}>{source.dataset_id} · {source.sample_count} 条 · {source.source_id.slice(0, 8)}</option>)}
            </select>
          </label>
          {selectedSource && <div className="text-xs text-text-secondary">{sources.find((item) => item.source_id === selectedSource)?.field_names?.join('、')} · 本地文件哈希可校验，官方来源待核实</div>}
          <button onClick={handleValidate} disabled={!selectedSource || busy} className="rounded-md border border-border-light px-3 py-2 text-sm disabled:opacity-50">验证结构与文件状态</button>
          <label className="block text-sm">输出版本名称
            <input value={versionName} maxLength={80} onChange={(event) => setVersionName(event.target.value)} className="mt-1 w-full rounded-md border border-border-light px-3 py-2" required />
          </label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={cleaningEnabled} onChange={(event) => setCleaningEnabled(event.target.checked)} />启用基础格式清洗</label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={nearDuplicateEnabled} onChange={(event) => setNearDuplicateEnabled(event.target.checked)} />启用近似重复检测（只进待审队列）</label>
          <label className="block text-sm">近似重复阈值（Hamming 距离）
            <input type="number" min={0} max={64} step={1} value={nearDuplicateDistance} onChange={(event) => setNearDuplicateDistance(Number(event.target.value))} className="mt-1 w-28 rounded-md border border-border-light px-3 py-2" />
          </label>
          <div className="text-sm text-text-secondary">中文脱敏规则仍需真实样本准确率验证；任务结果会标明规则版本。</div>
          <button onClick={handleCreateTask} disabled={!selectedSource || busy || !versionName.trim()} className="rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">启动处理任务</button>
        </section>
      </section>

      <section hidden={activePanel !== 'tasks'} className="rounded-xl border border-border-light bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-lg font-medium">处理任务</h2>
          <button onClick={() => refresh().catch((cause) => setError(errorMessage(cause)))} className="rounded-md border border-border-light px-3 py-2 text-sm">刷新</button></div>
        <div className="mt-4 grid gap-2 md:grid-cols-2">
          {tasks.map((task) => <button key={task.task_id} onClick={() => { setSearchParams((current) => { const next = new URLSearchParams(current); next.set('task_id', task.task_id); next.set('source_id', task.source_id); return next; }, { replace: true }); setResults(null); }}
            className={`rounded-lg border p-3 text-left ${task.task_id === selectedTask ? 'border-blue-500 bg-blue-50' : 'border-border-light'}`}>
            <div className="flex justify-between gap-2"><span className="font-medium">{statusLabels[task.status] || task.status}</span><span className="text-xs text-text-secondary">{stageLabels[task.current_step] || task.current_step}</span></div>
            <div className="mt-1 truncate text-xs text-text-secondary">{task.task_id}</div>
            <div className="mt-2 text-sm">{task.processed || 0} / {task.total || 0} 条</div>
          </button>)}
          {!tasks.length && <p className="text-sm text-text-secondary">暂无处理任务。</p>}
        </div>
        {activeTask && <div className="mt-5 border-t border-border-light pt-4">
          <div className="flex flex-wrap items-center justify-between gap-3"><div><b>{statusLabels[activeTask.status]}</b><span className="ml-2 text-sm text-text-secondary">步骤：{stageLabels[activeTask.current_step] || activeTask.current_step}</span>
            <div className="mt-1 text-sm">已处理 {activeTask.processed || 0} / {activeTask.total || 0} 条</div></div>
            <div className="text-sm text-text-secondary">运行时长：{runtimeText(activeTask)}</div>
            <div className="flex gap-2">
              {['pending', 'running'].includes(activeTask.status) && <button onClick={handleCancel} className="rounded-md border border-border-light px-3 py-2 text-sm">取消</button>}
              {activeTask.status === 'failed' && <button onClick={handleRetry} className="rounded-md border border-border-light px-3 py-2 text-sm">重试</button>}
              {activeTask.status === 'completed' && <button onClick={() => setActivePanel('results')} className="rounded-md bg-blue-700 px-3 py-2 text-sm text-white">查看质量报告</button>}
            </div></div>
          {activeTask.status === 'failed' && <p role="alert" className="mt-3 text-sm text-red-700">{activeTask.error}</p>}
          <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-5" aria-label="处理阶段">
            {['schema_and_cleaning', 'deduplication', 'privacy', 'quality_report', 'completed'].map((stage) => {
              const entries = (activeTask.logs || []).filter((item: any) => item.stage === stage);
              const current = activeTask.current_step === stage;
              const state = current ? '运行中' : entries.length || activeTask.status === 'completed' ? '已执行' : '等待';
              return <div key={stage} className="rounded-lg bg-background-secondary p-3 text-sm"><div className="font-medium">{stageLabels[stage]}</div><div className="mt-1 text-xs text-text-secondary">{state}{entries.length ? ` · ${entries[entries.length - 1].processed ?? 0} 条` : ''}</div></div>;
            })}
          </div>
        </div>}
      </section>

      <section hidden={activePanel !== 'review'} className="space-y-4 rounded-xl border border-border-light bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div><h2 className="text-lg font-medium">人工复核队列</h2><p className="mt-1 text-sm text-text-secondary">复核决定会写入后端历史，并基于原始输入重新处理生成独立版本。</p></div>
          <label className="text-sm">问题类型
              <select aria-label="问题类型筛选" value={reviewFilter} onChange={(event) => { setReviewFilter(event.target.value); setReviewOffset(0); }} className="ml-2 rounded-md border border-border-light px-2 py-1">
              <option value="">全部</option>
              {[...new Set(reviewItems.flatMap((item) => item.reasons || []))].map((reason) => <option key={reason} value={reason}>{reason}</option>)}
            </select>
          </label>
        </div>
        {!selectedTask && <p className="text-sm text-text-secondary">请先选择一个已完成的处理任务。</p>}
        {selectedTask && <div className="grid gap-4 lg:grid-cols-[minmax(240px,1fr)_2fr]">
          <div className="space-y-2">
            {reviewItems.map((item) => <button key={item.sample_id} type="button"
              onClick={() => setSelectedReviewId(item.sample_id)} className={`w-full rounded-md border p-3 text-left text-sm ${selectedReviewId === item.sample_id ? 'border-blue-500 bg-blue-50' : 'border-border-light'}`}>
              <div className="font-medium">{item.sample_id}</div><div className="mt-1 text-xs text-text-secondary">{item.status} · {(item.reasons || []).join('、')} · {item.decision}</div>
            </button>)}
            {!reviewItems.length && <p className="text-sm text-text-secondary">当前任务没有待复核样本。</p>}
            {reviewTotal > 20 && <div className="flex items-center justify-between pt-2 text-xs">
              <button disabled={reviewOffset === 0} onClick={() => setReviewOffset(Math.max(0, reviewOffset - 20))} className="rounded border px-2 py-1 disabled:opacity-50">上一页</button>
              <span>{reviewOffset + 1}–{Math.min(reviewOffset + reviewItems.length, reviewTotal)} / {reviewTotal}</span>
              <button disabled={reviewOffset + reviewItems.length >= reviewTotal} onClick={() => setReviewOffset(reviewOffset + 20)} className="rounded border px-2 py-1 disabled:opacity-50">下一页</button>
            </div>}
          </div>
          {selectedReview && <div className="space-y-3">
            <div className="text-xs text-text-secondary">样本 {selectedReview.sample_id} · 处理状态 {selectedReview.status} · {(selectedReview.reasons || []).join('、')}</div>
            <label className="block text-sm">问题内容<textarea aria-label="复核问题内容" value={reviewDraft.instruction} onChange={(event) => setReviewDraft((current) => ({ ...current, instruction: event.target.value }))} rows={5} className="mt-1 w-full rounded-md border border-border-light p-3" /></label>
            <label className="block text-sm">答案内容<textarea aria-label="复核答案内容" value={reviewDraft.output} onChange={(event) => setReviewDraft((current) => ({ ...current, output: event.target.value }))} rows={5} className="mt-1 w-full rounded-md border border-border-light p-3" /></label>
            <label className="block text-sm">复核备注<input aria-label="复核备注" value={reviewDraft.notes} onChange={(event) => setReviewDraft((current) => ({ ...current, notes: event.target.value }))} className="mt-1 w-full rounded-md border border-border-light px-3 py-2" /></label>
            <div className="flex flex-wrap gap-2">
              <button disabled={busy} onClick={() => handleReview('accept')} className="rounded-md bg-emerald-700 px-3 py-2 text-sm text-white disabled:opacity-50">接受当前内容</button>
              <button disabled={busy} onClick={() => handleReview('edit')} className="rounded-md bg-blue-700 px-3 py-2 text-sm text-white disabled:opacity-50">保存修改并重新检查</button>
              <button disabled={busy} onClick={() => handleReview('quarantine')} className="rounded-md border border-amber-500 px-3 py-2 text-sm text-amber-800 disabled:opacity-50">隔离</button>
              <button disabled={busy} onClick={() => handleReview('reject')} className="rounded-md border border-red-300 px-3 py-2 text-sm text-red-700 disabled:opacity-50">驳回</button>
            </div>
          </div>}
        </div>}
        <div className="border-t border-border-light pt-4"><h3 className="font-medium">复核历史</h3>
          {reviewHistory.map((item, index) => <div key={`${item.sample_id}-${item.reviewed_at}-${index}`} className="mt-2 rounded-md bg-background-secondary p-3 text-xs">
            {item.sample_id} · {item.decision} · {item.reviewer_id} · {item.reviewed_at} · {item.notes || '无备注'}
          </div>)}
          {!reviewHistory.length && <p className="mt-2 text-sm text-text-secondary">暂无复核记录。</p>}
        </div>
      </section>

      <div hidden={activePanel !== 'results'}>
      {results && activeTask?.status === 'completed' ? <>
        <section className="rounded-xl border border-border-light bg-white p-5">
          <h2 className="text-lg font-medium">数据流转</h2>
          <p className="mt-1 text-xs text-text-secondary">阶段吞吐量与终态分流分别统计；清洗、脱敏和重复候选等事件可能重叠。</p>
          <div className="mt-4 space-y-2">{(results.statistics?.stages || []).map((stage: any) => <details key={stage.stage} className="rounded-md bg-blue-50 p-3 text-sm">
            <summary className="cursor-pointer font-medium">{stage.stage} · {stage.input_count} → {stage.output_count} 条 · {stage.status}</summary>
            <div className="mt-2 h-2 overflow-hidden rounded bg-blue-100"><div className="h-full bg-blue-600" style={{ width: `${stage.input_count ? Math.min(100, stage.output_count / stage.input_count * 100) : 0}%` }} /></div>
            <div className="mt-2 text-xs">处理 {stage.processed_count} 条 · 异常 {stage.error_count} · 耗时 {stage.duration_seconds} 秒</div>
            <pre className="mt-2 overflow-auto whitespace-pre-wrap text-xs">{JSON.stringify(stage.rules, null, 2)}</pre>
          </details>)}</div>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">{[['合格', results.statistics?.final_retained_count], ['待复核', results.statistics?.review_count], ['隔离', results.statistics?.quarantine_count], ['删除', results.statistics?.drop_count]].map(([label, value]) => <div key={String(label)} className="rounded-md border border-border-light p-3 text-sm">{label} <b>{value ?? 'N/A'}</b></div>)}</div>
        </section>
        <section className="rounded-xl border border-border-light bg-white p-5">
          <h2 className="text-lg font-medium">处理统计</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ['原始样本', results.statistics?.raw_sample_count], ['清洗异常', results.statistics?.cleaning_anomaly_count],
              ['完全重复', results.statistics?.exact_duplicate_count], ['归一化重复', results.statistics?.normalized_duplicate_count],
              ['脱敏命中', results.statistics?.privacy_hit_count], ['待复核', results.statistics?.review_count],
              ['隔离', results.statistics?.quarantine_count], ['最终合格', results.statistics?.final_retained_count],
            ].map(([label, value]) => <div key={String(label)} className="rounded-lg bg-background-secondary p-3"><div className="text-xs text-text-secondary">{label}</div><div className="mt-1 text-xl font-semibold">{value ?? 'N/A'}</div></div>)}
          </div>
          <p className="mt-3 text-sm text-text-secondary">质量准入：{results.gate?.decision || 'N/A'} · {results.gate?.reasons?.join('；') || ''}</p>
        </section>

        <section className="rounded-xl border border-border-light bg-white p-5">
          <h2 className="text-lg font-medium">五维质量画像</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {Object.entries(results.quality?.metrics || {}).map(([key, metrics]: [string, any]) => <article key={key} className="rounded-lg border border-border-light p-4">
              <h3 className="font-medium">{dimensionLabels[key] || key}</h3>
              {Object.entries(metrics || {}).filter(([, item]: [string, any]) => item && typeof item === 'object' && 'value' in item).map(([name, item]: [string, any]) => <div key={name} className="mt-3 border-t border-border-light pt-2 text-sm">
                <div className="flex justify-between gap-2"><span>{name}</span><strong>{valueText(item.value)}</strong></div>
                <div className="mt-1 text-xs text-text-secondary">分子 / 分母：{item.numerator ?? 'N/A'} / {item.denominator ?? 'N/A'}</div>
                <div className="mt-1 text-xs text-text-secondary">公式：{item.formula || 'N/A'} · 范围：{item.scope || 'N/A'}</div>
                {item.not_measurable_reason && <div className="mt-1 text-xs text-amber-700">{item.not_measurable_reason}</div>}
              </div>)}
            </article>)}
          </div>
          <p className="mt-3 text-xs text-text-secondary">无偏性或时效性不可测时显示 N/A；五维质量不代表模型训练效用。</p>
        </section>

        <section className="rounded-xl border border-border-light bg-white p-5">
          <h2 className="text-lg font-medium">待复核问题</h2>
          <p className="mt-1 text-xs text-text-secondary">仅展示脱敏后的问题元数据，不展示原始文本。</p>
          <div className="mt-3 space-y-2">{results.review_samples?.map((row: any, index: number) => <div key={`${row.sample_id}-${index}`} className="rounded-md bg-background-secondary p-3 text-sm">
            <div className="font-medium">{row.sample_id || '解析异常记录'} · {row.status}</div>
            <div className="mt-1 text-text-secondary">{(row.reasons || [row.reason]).filter(Boolean).join('、') || '需人工复核'}</div>
            {row.near_duplicate_sample_ids?.length > 0 && <div className="mt-1 text-xs">重复簇候选：{row.near_duplicate_sample_ids.join('、')}</div>}
          </div>)}
            {!results.review_samples?.length && <p className="text-sm text-text-secondary">暂无待复核项目。</p>}
          </div>
          <div className="mt-4 flex flex-wrap gap-2">{results.files?.map((name: string) => <button key={name} onClick={() => downloadPreprojectFile(selectedTask, name).catch((cause) => setError(errorMessage(cause)))} className="rounded-md border border-border-light px-3 py-2 text-sm">下载 {name}</button>)}</div>
        </section>
        <section className="rounded-xl border border-border-light bg-white p-5">
          <h2 className="text-lg font-medium">问题分布与样本对照</h2>
          <p className="mt-1 text-xs text-text-secondary">处理事件可能重叠，不相加作为问题样本总数。两侧内容都经过隐私规则处理。</p>
          <div className="mt-3 flex flex-wrap gap-2">{[
            ['全部样本', '', results.statistics?.raw_sample_count], ['完全重复', 'exact_duplicate', results.statistics?.exact_duplicate_count],
            ['归一化重复', 'normalized_duplicate', results.statistics?.normalized_duplicate_count], ['近似重复候选', 'near_duplicate_requires_review', results.statistics?.near_duplicate_sample_count],
            ['敏感信息命中（次数）', 'privacy_hit', results.statistics?.privacy_hit_count], ['疑似答案冲突', 'answer_conflict_requires_review', null],
            ['字段缺失', 'missing_instruction_or_output', null], ['编码异常', 'replacement_character_encoding_suspected', null],
          ].map(([label, issue, count]) => <button key={String(issue)} onClick={() => { setSampleIssue(String(issue)); setSampleOffset(0); }} className={`rounded-md border px-3 py-2 text-sm ${sampleIssue === issue ? 'border-blue-500 bg-blue-50' : 'border-border-light'}`}>{label} · {count ?? '查看'}</button>)}</div>
          <div className="mt-4 space-y-3">{samples?.items?.map((sample: any) => <details key={sample.sample_id} className="rounded-lg border border-border-light p-3"><summary className="cursor-pointer text-sm">{sample.sample_id} · {sample.status} · {(sample.reasons || []).join('、') || '无异常'}</summary><div className="mt-3 grid gap-3 lg:grid-cols-2">{[['治理前（脱敏）', sample.before], ['处理后（脱敏）', sample.after]].map(([label, value]) => <div key={String(label)} className="min-w-0 rounded bg-background-secondary p-3 text-sm"><b>{label}</b><pre className="mt-2 whitespace-pre-wrap break-words text-xs">{JSON.stringify(value, null, 2)}</pre></div>)}</div><p className="mt-2 text-xs">清洗规则：{(sample.cleaning_changes || []).join('、') || '无修改'} · 重复类型：{sample.duplicate_type || '无'}</p></details>)}
            {samples && !samples.items?.length && <p className="text-sm text-text-secondary">此类别没有样本。</p>}</div>
          <div className="mt-3 flex gap-3 text-sm"><button disabled={sampleOffset === 0} onClick={() => setSampleOffset(Math.max(0, sampleOffset - 10))}>上一页</button><span>{samples?.total ?? 0} 条</span><button disabled={!samples || sampleOffset + 10 >= samples.total} onClick={() => setSampleOffset(sampleOffset + 10)}>下一页</button></div>
        </section>
      </> : <section className="rounded-xl border border-border-light bg-white p-5">
        <h2 className="text-lg font-medium">结果与报告</h2>
        <p className="mt-2 text-sm text-text-secondary">{activeTask ? `当前任务：${statusLabels[activeTask.status]}。任务完成后会在此显示统计、五维质量画像、待复核队列和下载文件。` : '请在“任务执行”中选择一个已完成的任务。此处只展示后端实际生成的结果。'}</p>
        {activeTask?.status === 'completed' && <p className="mt-2 text-sm">正在读取任务结果…</p>}
      </section>}
      </div>

      <section hidden={activePanel !== 'versions'} className="rounded-xl border border-border-light bg-white p-5">
        <h2 className="text-lg font-medium">数据版本</h2>
        <p className="mt-1 text-sm text-text-secondary">Raw、Processed和复核版本独立留存；版本清单包含父版本、样本数和授权状态。</p>
        <div className="mt-4 flex flex-wrap items-end gap-2">
          {[['对比前', leftVersion, setLeftVersion], ['对比后', rightVersion, setRightVersion]].map(([label, value, setter]) => <label key={String(label)} className="text-sm">{String(label)}<select value={String(value)} onChange={(event) => (setter as React.Dispatch<React.SetStateAction<string>>)(event.target.value)} className="ml-2 max-w-xs rounded border p-2"><option value="">选择版本</option>{versions.map((version) => <option key={version.version_id} value={version.version_id}>{version.version_type} · {version.version_id}</option>)}</select></label>)}
          <button disabled={!leftVersion || !rightVersion} onClick={() => comparePreprojectVersions(leftVersion, rightVersion).then(setVersionComparison).catch((cause) => setError(errorMessage(cause)))} className="rounded-md border border-border-light px-3 py-2 text-sm disabled:opacity-50">比较版本</button>
        </div>
        {versionComparison && <div className="mt-3 rounded bg-blue-50 p-3 text-sm">新增 {versionComparison.added_count} · 删除 {versionComparison.removed_count} · 内容变化 {versionComparison.changed_count ?? 'N/A'} · 状态变化 {versionComparison.status_changed_count ?? 'N/A'}{versionComparison.reason && <p>{versionComparison.reason}</p>}</div>}
        {results?.files && <div className="mt-4 flex flex-wrap gap-2">{results.files.map((name: string) => <button key={name} onClick={() => downloadPreprojectFile(selectedTask, name).catch((cause) => setError(errorMessage(cause)))} className="rounded-md border border-border-light px-3 py-2 text-sm">下载 {name}</button>)}</div>}
        <div className="mt-4 space-y-2">{versions.map((version) => <article key={version.version_id} className="rounded-md border border-border-light p-3 text-sm">
          <div className="flex flex-wrap justify-between gap-2"><b>{version.version_type} · {version.status}</b><span>{version.sample_count} 条 · {version.created_at}</span></div>
          <div className="mt-1 break-all text-xs text-text-secondary">版本 {version.version_id} · 父版本 {version.parent_version_id || '无'}</div>
          <div className="mt-1 text-xs text-amber-800">版本核验：{version.revision_verification_status || '未验证'} · 许可：{version.license_verification_status || '未验证'} · 授权：{version.authorization_status || '未确认'}</div>
          {version.version_type !== 'raw' && <button disabled={busy} onClick={() => handleReleaseCandidate(version.version_id)} className="mt-2 rounded-md border border-border-light px-3 py-1.5 text-xs disabled:opacity-50">申请生成发布候选</button>}
        </article>)}
          {!versions.length && <p className="text-sm text-text-secondary">暂无登记版本。</p>}
        </div>
      </section>
    </main>
  );
};

export default PreprojectDataPage;
