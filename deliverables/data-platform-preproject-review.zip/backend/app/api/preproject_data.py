"""预立项数据源、处理任务及安全下载 API。"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import shutil
import sys
import threading
import uuid
from typing import Literal
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from data_pipeline.cleaning import clean_record
from data_pipeline.deduplication import deduplicate
from data_pipeline.pipeline import (
    PipelineCancelled, _apply_license_boundary, _build_quality_report, _read_local_source, run_pipeline, sha256_file,
)
from data_pipeline.privacy import inspect_and_mask
from data_pipeline.quality import calculate_quality
from data_pipeline.schema import _stable_sample_id, normalize_record, public_record
from data_pipeline.source import DatasetViewerClient
from app.api.auth import get_current_user
from app.core.database import SessionLocal, get_db
from app.models.dataset import Dataset
from app.models.user import User

router = APIRouter()
DATA_ROOT = Path(os.getenv("PREPROJECT_DATA_DIR", str(PROJECT_ROOT / "backend" / "data" / "preproject"))).resolve()
MAX_UPLOAD_BYTES = 100 * 1024 * 1024
MAX_SOURCE_ROWS = 100_000
ALLOWED_SUFFIXES = {".jsonl", ".json", ".parquet", ".pq"}
DOWNLOADABLE = {
    "processed.jsonl", "qualified.jsonl", "processing_actions.jsonl", "statistics.json", "quality_metrics.json", "quality_report.md",
    "dataset_manifest.json", "dedup_report.json", "privacy_report.json", "review_queue.jsonl",
    "reviewed_processed.jsonl", "reviewed_statistics.json", "reviewed_quality_metrics.json",
    "reviewed_quality_report.md", "reviewed_manifest.json",
}
_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="preproject-data")
_lock = threading.RLock()
_tasks: dict[str, dict[str, Any]] = {}
_cancel_events: dict[str, threading.Event] = {}
_fetch_jobs: dict[str, dict[str, Any]] = {}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _owner_key(user: User) -> str:
    return hashlib.sha256(str(user.id).encode("utf-8")).hexdigest()[:24]


def _require_operator(user: User = Depends(get_current_user)) -> User:
    if getattr(user, "user_type", None) not in {"buyer", "admin"}:
        raise HTTPException(status_code=403, detail="当前角色无权管理预立项数据")
    return user


def _user_root(user: User) -> Path:
    return DATA_ROOT / "users" / _owner_key(user)


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=500, detail=f"任务或数据源记录不可读取：{type(exc).__name__}") from None
    if not isinstance(value, dict):
        raise HTTPException(status_code=500, detail="任务或数据源记录格式错误")
    return value


def _source_path(user: User, source_id: str) -> Path:
    if not re.fullmatch(r"[0-9a-f]{32}", source_id):
        raise HTTPException(status_code=404, detail="数据源不存在")
    directory = _user_root(user) / "sources" / source_id
    manifest_path = directory / "source_manifest.json"
    if not manifest_path.is_file():
        raise HTTPException(status_code=404, detail="数据源不存在")
    return directory


def _load_source(user: User, source_id: str) -> tuple[dict[str, Any], Path]:
    directory = _source_path(user, source_id)
    manifest = _read_json(directory / "source_manifest.json")
    input_path = directory / str(manifest.get("stored_filename", ""))
    if not input_path.is_file() or input_path.parent.resolve() != directory.resolve():
        raise HTTPException(status_code=410, detail="数据源文件已不存在")
    return manifest, input_path


def _task_path(user: User, task_id: str) -> Path:
    if not re.fullmatch(r"[0-9a-f]{32}", task_id):
        raise HTTPException(status_code=404, detail="处理任务不存在")
    path = _user_root(user) / "tasks" / task_id / "task.json"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="处理任务不存在")
    return path


def _get_task(user: User, task_id: str) -> dict[str, Any]:
    with _lock:
        task = _tasks.get(task_id)
    if task is None:
        task = _read_json(_task_path(user, task_id))
        if task.get("status") in {"pending", "running"}:
            task.update(status="failed", current_step="interrupted", ended_at=_now(),
                        error="后端进程已重启，任务未自动续跑；请检查数据后重试。")
            _store_task(task)
    if task.get("owner_key") != _owner_key(user):
        raise HTTPException(status_code=404, detail="处理任务不存在")
    return task


def _store_task(task: dict[str, Any]) -> None:
    with _lock:
        _tasks[task["task_id"]] = task
        directory = Path(task["task_dir"])
        _atomic_json(directory / "task.json", task)


def _load_pipeline_config() -> dict[str, Any]:
    return json.loads((PROJECT_ROOT / "configs" / "preproject_pipeline.json").read_text(encoding="utf-8"))


def _jsonl_rows(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as stream:
        for line in stream:
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                rows.append(value)
    return rows


def _safe_normalized_sample(user: User, task: dict[str, Any], sample_id: str,
                            source_rows: list[tuple[int, dict[str, Any]]] | None = None) -> dict[str, Any] | None:
    """Load one source row, normalize it, clean it, and mask PII before preview/review."""
    source_manifest, input_path = _load_source(user, str(task["source_id"]))
    rows = source_rows
    if rows is None:
        rows, _issues, _nonblank, _errors = _read_local_source(input_path)
    source_row = None
    for line_number, row in rows:
        row_key = row.get("id", row.get("hf_row_idx", row.get("row_idx", line_number)))
        derived_id = str(row.get("sample_id") or _stable_sample_id(
            str(source_manifest.get("dataset_id", "local-unknown")), str(source_manifest.get("revision", "unversioned")),
            str(source_manifest.get("split", "local")), str(row_key)))
        if derived_id == sample_id:
            source_row = row
            break
    if source_row is None:
        return None
    config = _load_pipeline_config()
    task_parameters = task.get("parameters", {})
    defaults = {
        "dataset_id": source_manifest.get("dataset_id"),
        "source_id": f"local-upload:{source_manifest.get('source_id')}",
        "source_url": source_manifest.get("source_url", ""),
        "license": source_manifest.get("license", "unknown"),
        "revision": source_manifest.get("revision", "unknown"),
        "split": source_manifest.get("split", "local"),
        "data_subset_id": task_parameters.get("version_name", "reviewed"),
        "version_id": source_manifest.get("version_id", "raw"),
    }
    record = normalize_record(source_row, defaults=defaults, line_number=1)
    if task_parameters.get("cleaning_enabled", True):
        clean_record(record, config.get("engineering_screens", {}))
    else:
        record["status_history"].append({"stage": "cleaning", "status": "skipped_by_config"})
    inspect_and_mask(record, config.get("privacy", {}))
    return record


def _version_record_path(user: User, version_id: str) -> Path:
    if not re.fullmatch(r"(?:raw|processed|reviewed|candidate)_[0-9a-f]{20,64}", version_id):
        raise HTTPException(status_code=404, detail="数据版本不存在")
    root = _user_root(user)
    matches = list(root.glob(f"sources/*/versions/{version_id}.json")) + list(root.glob(f"tasks/*/versions/{version_id}.json"))
    if not matches:
        raise HTTPException(status_code=404, detail="数据版本不存在")
    return matches[0]


def _unchanged_since_hash(path: Path, manifest: dict[str, Any]) -> bool | None:
    recorded_size = manifest.get("file_size_bytes")
    recorded_mtime = manifest.get("file_mtime_ns")
    if recorded_size is None or recorded_mtime is None:
        return None
    stat = path.stat()
    return stat.st_size == int(recorded_size) and stat.st_mtime_ns == int(recorded_mtime)


def _rebuild_reviewed_version(user: User, task: dict[str, Any], states: dict[str, Any]) -> dict[str, Any]:
    """Re-run the source pipeline with persisted reviewer decisions into a separate immutable version."""
    source_manifest, input_path = _load_source(user, str(task["source_id"]))
    config = _load_pipeline_config()
    parameters = task.get("parameters", {})
    config["source"] = {
        "enabled": False, "dataset_id": source_manifest["dataset_id"],
        "source_id": f"local-upload:{source_manifest['source_id']}",
        "source_url": source_manifest.get("source_url", ""), "license": source_manifest.get("license", "unknown"),
        "revision": source_manifest.get("revision", "unknown"), "split": source_manifest.get("split", "local"),
    }
    config["data_subset_id"] = parameters.get("version_name", "reviewed")
    config["cleaning_enabled"] = bool(parameters.get("cleaning_enabled", True))
    config["deduplication"]["near_duplicate_enabled"] = bool(parameters.get("near_duplicate_enabled", True))
    config["deduplication"]["near_duplicate_hamming_distance"] = int(parameters.get("near_duplicate_hamming_distance", 3))
    config["privacy_enabled"] = True

    rows, parse_issues, nonblank, parse_errors = _read_local_source(input_path)
    records: list[dict[str, Any]] = []
    state_by_sample = states.get("items", {}) if isinstance(states.get("items"), dict) else {}
    for line_number, source_row in rows:
        record = normalize_record(source_row, defaults={**config["source"], "data_subset_id": config["data_subset_id"]},
                                  line_number=line_number)
        state = state_by_sample.get(str(record.get("sample_id")), {})
        edits = state.get("edited_content") if isinstance(state, dict) else None
        if isinstance(edits, dict):
            for key in ("instruction", "input", "output", "system"):
                if key in edits:
                    record[key] = str(edits[key])
            record["status_history"].append({"stage": "human_edit", "status": "recheck"})
        _apply_license_boundary(record, config.get("license_policy", {}))
        if config["cleaning_enabled"] or isinstance(edits, dict):
            clean_record(record, config.get("engineering_screens", {}))
        else:
            record["status_history"].append({"stage": "cleaning", "status": "skipped_by_config"})
        records.append(record)

    dedup_report = deduplicate(records, config.get("deduplication", {}))
    for record in records:
        record["status_history"].append({"stage": "deduplication", "status": record["processing_status"]})
    detected: dict[str, int] = {}
    masked: dict[str, int] = {}
    residual: dict[str, int] = {}
    for record in records:
        hits, replacements, leftovers = inspect_and_mask(record, config.get("privacy", {}))
        for key, count in hits.items(): detected[key] = detected.get(key, 0) + count
        for key, count in replacements.items(): masked[key] = masked.get(key, 0) + count
        for key, count in leftovers.items(): residual[key] = residual.get(key, 0) + count
        record["content_hash"] = hashlib.sha256("\x1f".join(str(record.get(key, "") or "") for key in ("instruction", "input", "output")).encode("utf-8")).hexdigest()

    state_to_status = {"accept": "keep", "quarantine": "quarantine", "reject": "drop"}
    for record in records:
        state = state_by_sample.get(str(record.get("sample_id")))
        if not isinstance(state, dict):
            continue
        wanted = state_to_status.get(str(state.get("decision")))
        if wanted and wanted in {"keep", "review", "quarantine", "drop"}:
            if wanted == "keep" and record.get("processing_status") == "review":
                record["processing_status"] = "keep"
                record["processing_reasons"].append("human_review_accepted")
            elif wanted == "review" and record.get("processing_status") not in {"drop", "quarantine"}:
                record["processing_status"] = "review"
                record["processing_reasons"].append("edited_content_requires_full_recheck")
            elif wanted in {"quarantine", "drop"}:
                record["processing_status"] = wanted
            if isinstance(record.get("privacy_audit"), dict):
                record["privacy_audit"]["status"] = record["processing_status"]
            record["status_history"].append({"stage": "human_review", "status": record["processing_status"]})

    privacy_report = {"detected_counts": detected, "masked_counts": masked, "residual_counts": residual,
                      "residual_scan_passed": not any(residual.values()), "patterns_version": "privacy-patterns-v1",
                      "plaintext_sensitive_values_logged": False}
    quality = calculate_quality(records, parse_error_count=parse_errors, nonblank_line_count=nonblank,
                                dedup_report=dedup_report, privacy_report=privacy_report,
                                config=config.get("quality", {}))
    status_counts: dict[str, int] = {}
    for record in records:
        status = str(record.get("processing_status", "quarantine"))
        status_counts[status] = status_counts.get(status, 0) + 1
    status_counts["quarantine"] = status_counts.get("quarantine", 0) + parse_errors
    eligible = [record for record in records if record.get("processing_status") == "keep"
                and isinstance(record.get("instruction"), str) and record["instruction"].strip()
                and isinstance(record.get("output"), str) and record["output"].strip()]
    eligible.sort(key=lambda record: str(record["sample_id"]))
    version_material = json.dumps({key: {"decision": value.get("decision"), "edited_content": value.get("edited_content")}
                                   for key, value in sorted(state_by_sample.items()) if isinstance(value, dict)},
                                  ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    version_id = "reviewed_" + hashlib.sha256(
        f"{source_manifest.get('file_sha256', '')}:{task.get('config_fingerprint', '')}:{version_material}".encode("utf-8")
    ).hexdigest()[:24]
    version_dir = Path(task["task_dir"]) / "versions" / version_id
    version_dir.mkdir(parents=True, exist_ok=True)
    output_path = version_dir / "reviewed_processed.jsonl"
    temporary = output_path.with_suffix(".jsonl.tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        for record in eligible:
            stream.write(json.dumps(public_record(record), ensure_ascii=False, sort_keys=True) + "\n")
    temporary.replace(output_path)
    output_stats = dict(task.get("statistics") or {})
    status_total = sum(status_counts.values())
    if status_total != nonblank:
        raise ValueError(f"复核版本样本状态不守恒：输入 {nonblank}，终态 {status_total}。")
    output_stats.update({"raw_sample_count": len(records), "parse_error_count": parse_errors,
                         "status_counts": dict(sorted(status_counts.items())), "review_count": status_counts.get("review", 0),
                         "quarantine_count": status_counts.get("quarantine", 0), "drop_count": status_counts.get("drop", 0),
                         "final_retained_count": len(eligible), "manual_review_decision_count": len(state_by_sample),
                         "status_count_total": status_total, "status_count_conserved": True,
                         "five_dimensions": quality["metrics"]})
    reviewed_stats_path = version_dir / "reviewed_statistics.json"
    _atomic_json(reviewed_stats_path, output_stats)
    reviewed_quality_path = version_dir / "reviewed_quality_metrics.json"
    _atomic_json(reviewed_quality_path, quality)
    reviewed_dedup_path = version_dir / "reviewed_dedup_report.json"
    _atomic_json(reviewed_dedup_path, dedup_report)
    reviewed_privacy_path = version_dir / "reviewed_privacy_report.json"
    _atomic_json(reviewed_privacy_path, privacy_report)
    gate = dict(task.get("gate") or {})
    report = _build_quality_report(source=source_manifest, statistics=output_stats, quality=quality,
                                   dedup=dedup_report, privacy=privacy_report,
                                   processing_flow=["原始数据重新读取", "人工复核决策应用", "清洗与去重重跑",
                                                    "脱敏与残留复检重跑", "五维质量重新计算", "复核版本导出"], gate=gate)
    report_path = version_dir / "reviewed_quality_report.md"
    report_path.write_text(report, encoding="utf-8")
    sample_ids_path = version_dir / "sample_ids.jsonl"
    sample_ids_path.write_text("".join(json.dumps(row["sample_id"], ensure_ascii=False) + "\n" for row in eligible), encoding="utf-8")
    manifest = {"manifest_version": 1, "version_id": version_id, "parent_version_id": task.get("version_id"),
                "version_type": "reviewed_processed", "source_id": task["source_id"], "task_id": task["task_id"],
                "sample_count": len(eligible), "sample_ids_path": str(sample_ids_path.resolve()),
                "raw_sha256": source_manifest.get("file_sha256"), "processed_sha256": sha256_file(output_path),
                "processed_path": str(output_path.resolve()),
                "statistics_path": str(reviewed_stats_path.resolve()), "quality_metrics_path": str(reviewed_quality_path.resolve()),
                "quality_report_path": str(report_path.resolve()), "status": "reviewed_candidate",
                "quality_gate": gate, "license": source_manifest.get("license", "unknown"),
                "license_verification_status": "verified" if source_manifest.get("license_verified") else "unverified",
                "revision": source_manifest.get("revision", "unknown"),
                "revision_verification_status": "verified" if source_manifest.get("revision_verified") else "unverified",
                "authorization_status": "unverified_or_not_authorized", "created_at": _now()}
    _atomic_json(Path(task["task_dir"]) / "versions" / f"{version_id}.json", manifest)
    task["reviewed_version_id"] = version_id
    _store_task(task)
    return manifest


class CreateTaskRequest(BaseModel):
    source_id: str = Field(min_length=32, max_length=32)
    cleaning_enabled: bool = True
    near_duplicate_enabled: bool = True
    near_duplicate_hamming_distance: int = Field(default=3, ge=0, le=64)
    near_duplicate_action: str = Field(default="review_only", pattern="^review_only$")
    privacy_enabled: bool = True
    version_name: str = Field(default="preproject-run", min_length=1, max_length=80)


class FetchRequest(BaseModel):
    count: Literal[200, 5000]


class ReviewRequest(BaseModel):
    sample_id: str = Field(min_length=1, max_length=160)
    decision: Literal["accept", "edit", "quarantine", "reject"]
    issue_type: str = Field(default="", max_length=160)
    edited_content: dict[str, str] | None = None
    notes: str = Field(default="", max_length=2000)


def _run_fetch(fetch_id: str, user_id: str, owner_key: str, count: int, source_id: str, directory: Path) -> None:
    with _lock:
        job = _fetch_jobs[fetch_id]
        job.update(status="running", started_at=_now(), current_step="official_metadata_and_license")
        _atomic_json(directory / "fetch_job.json", job)
    try:
        config_path = PROJECT_ROOT / "configs" / "preproject_pipeline.json"
        config = json.loads(config_path.read_text(encoding="utf-8"))
        source = dict(config["source"])
        source["sample_count"] = count
        source["cache_dir"] = str(DATA_ROOT / "users" / owner_key / "cache")
        target = directory / ("educhat_raw_200.jsonl" if count == 200 else "educhat_raw_5k.jsonl")
        with _lock:
            job = _fetch_jobs[fetch_id]
            job.update(current_step="fetching_official_rows", total=count)
            _atomic_json(directory / "fetch_job.json", job)
        report = DatasetViewerClient(source, source["cache_dir"]).sample(source, target)
        raw_version_id = str(report.get("version_id") or f"raw_{str(report['file_sha256'])[:24]}")
        report.update({"source_id": source_id, "stored_filename": target.name, "file": target.name,
                       "source_type": "official_api", "version_id": raw_version_id,
                       "raw_file_path": str(target.resolve()), "created_at": _now(), "status": "imported",
                       "license_verification_status": "verified" if report.get("license_verified") else "unverified",
                       "revision_verification_status": "verified" if report.get("revision_verified") else "unverified"})
        manifest_path = directory / "source_manifest.json"
        _atomic_json(manifest_path, report)
        _atomic_json(directory / "versions" / f"{raw_version_id}.json", {
            "version_id": raw_version_id, "parent_version_id": None, "version_type": "raw",
            "source_id": source_id, "dataset_id": report.get("dataset_id"),
            "sample_count": report.get("sample_count"), "sample_ids_path": str((directory / "sample_ids.jsonl").resolve()),
            "raw_file_path": str(target.resolve()), "sha256": report.get("file_sha256"),
            "license": report.get("license", "unknown"),
            "license_verification_status": "verified" if report.get("license_verified") else "unverified",
            "revision": report.get("revision", "unknown"),
            "revision_verification_status": "verified" if report.get("revision_verified") else "unverified",
            "authorization_status": "authorized" if report.get("redistribution_authorized") else "unverified_or_not_authorized",
            "status": "imported", "created_at": report.get("acquired_at", _now()),
        })
        (directory / "sample_ids.jsonl").write_text(
            "".join(json.dumps(sample_id, ensure_ascii=False) + "\n" for sample_id in report.get("sample_ids", [])),
            encoding="utf-8")
        db = SessionLocal()
        try:
            db.add(Dataset(id=source_id, name=str(report.get("dataset_id", "EduChat"))[:200],
                           description="官方接口采集来源；核验状态以采集清单为准。", data_type="json", status="ready",
                           size_bytes=target.stat().st_size, row_count=int(report.get("sample_count", 0)),
                           column_count=len(report.get("field_names", [])), tags=["preproject", "raw", "official_fetch"],
                           columns_info={"source_id": source_id, "version_id": raw_version_id,
                                         "revision_verification_status": "verified" if report.get("revision_verified") else "unverified",
                                         "license_verification_status": "verified" if report.get("license_verified") else "unverified"},
                           owner_id=user_id))
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()
        with _lock:
            job = _fetch_jobs[fetch_id]
            job.update(status="completed", current_step="completed", processed=count, ended_at=_now(),
                        source_id=source_id, sample_count=count, file_sha256=report["file_sha256"], error=None)
            _atomic_json(directory / "fetch_job.json", job)
    except Exception as exc:
        with _lock:
            job = _fetch_jobs[fetch_id]
            job.update(status="failed", current_step="failed", ended_at=_now(),
                        error=f"{type(exc).__name__}: {str(exc)[:500]}")
            _atomic_json(directory / "fetch_job.json", job)


def _run_task(task_id: str, user_key: str, source_manifest: dict[str, Any], input_path: Path,
              task_dir: Path, request: CreateTaskRequest) -> None:
    with _lock:
        task = _tasks[task_id]
        event = _cancel_events[task_id]
        if event.is_set():
            task.update(status="cancelled", current_step="cancelled", ended_at=_now())
            _store_task(task)
            return
        task.update(status="running", current_step="starting", started_at=_now())
        _store_task(task)

    config_path = PROJECT_ROOT / "configs" / "preproject_pipeline.json"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        config["source"] = {
            "enabled": False,
            "dataset_id": source_manifest["dataset_id"],
            "source_id": f"local-upload:{source_manifest['source_id']}",
            "source_url": source_manifest["source_url"],
            "license": source_manifest["license"],
            "revision": source_manifest["revision"],
            "split": source_manifest["split"],
        }
        config["data_subset_id"] = request.version_name
        config["cleaning_enabled"] = request.cleaning_enabled
        config["deduplication"]["near_duplicate_enabled"] = request.near_duplicate_enabled
        config["deduplication"]["near_duplicate_hamming_distance"] = request.near_duplicate_hamming_distance
        config["deduplication"]["near_duplicate_action"] = request.near_duplicate_action
        config["privacy_enabled"] = request.privacy_enabled
        task.update(current_step="processing", total=source_manifest["sample_count"], processed=0)
        task["logs"] = [{"time": _now(), "stage": "processing", "message": "数据处理任务开始"}]
        _store_task(task)

        def progress(event: dict[str, Any]) -> None:
            stage = event.get("stage", "processing")
            processed = event.get("processed", task.get("processed", 0))
            should_log = stage != task.get("current_step") or processed == 0 or processed == event.get("total") or processed % 1000 == 0
            task.update(current_step=stage,
                        processed=processed,
                        total=event.get("total", task.get("total", 0)))
            if should_log:
                logs = task.setdefault("logs", [])
                logs.append({"time": _now(), "stage": stage, "processed": processed,
                             "total": event.get("total", task.get("total", 0))})
                del logs[:-200]
            _store_task(task)

        result = run_pipeline(
            input_path=input_path, output_dir=task_dir / "output", config=config, config_path=config_path,
            source_manifest_path=input_path.parent / "source_manifest.json",
            progress_callback=progress, cancel_check=event.is_set,
        )
        if event.is_set():
            raise PipelineCancelled("任务已取消。")
        output_dir = task_dir / "output"
        output_manifest = json.loads((output_dir / "dataset_manifest.json").read_text(encoding="utf-8"))
        output_rows = _jsonl_rows(output_dir / "processed.jsonl")
        source_version_id = str(source_manifest.get("version_id") or "")
        version_seed = f"{source_manifest.get('file_sha256', '')}:{task.get('config_fingerprint', '')}"
        processed_version_id = "processed_" + hashlib.sha256(version_seed.encode("utf-8")).hexdigest()[:24]
        version_dir = task_dir / "versions"
        version_dir.mkdir(parents=True, exist_ok=True)
        sample_ids_path = version_dir / f"{processed_version_id}_sample_ids.jsonl"
        sample_ids_path.write_text("".join(f"{json.dumps(row.get('sample_id'), ensure_ascii=False)}\n" for row in output_rows), encoding="utf-8")
        _atomic_json(version_dir / f"{processed_version_id}.json", {
            "version_id": processed_version_id, "parent_version_id": source_version_id or None,
            "version_type": "processed", "source_id": source_manifest.get("source_id"),
            "task_id": task_id, "dataset_id": source_manifest.get("dataset_id"),
            "sample_count": len(output_rows), "sample_ids_path": str(sample_ids_path.resolve()),
            "raw_file_path": str(input_path.resolve()), "processed_file_path": str((output_dir / "processed.jsonl").resolve()),
            "qualified_file_path": str((output_dir / "qualified.jsonl").resolve()),
            "raw_sha256": source_manifest.get("file_sha256"),
            "processed_sha256": (output_manifest.get("output") or {}).get("sha256"),
            "config_fingerprint": task.get("config_fingerprint"),
            "quality_report_path": str((output_dir / "quality_report.md").resolve()),
            "quality_metrics_path": str((output_dir / "quality_metrics.json").resolve()),
            "license": source_manifest.get("license", "unknown"),
            "license_verification_status": "verified" if source_manifest.get("license_verified") else "unverified",
            "revision": source_manifest.get("revision", "unknown"),
            "revision_verification_status": "verified" if source_manifest.get("revision_verified") else "unverified",
            "authorization_status": "authorized" if source_manifest.get("redistribution_authorized") else "unverified_or_not_authorized",
            "quality_gate": result["gate"], "status": "processed_candidate", "created_at": _now(),
        })
        with _lock:
            if event.is_set():
                raise PipelineCancelled("任务已取消。")
            task.update(status="completed", current_step="completed", processed=task.get("total", 0),
                        ended_at=_now(), statistics=result["statistics"], quality=result["quality"],
                        raw_version_id=source_version_id or None, version_id=processed_version_id,
                        gate=result["gate"], error=None)
            _store_task(task)
    except PipelineCancelled:
        task.update(status="cancelled", current_step="cancelled", ended_at=_now(), error=None)
    except Exception as exc:
        task.update(status="failed", current_step="failed", ended_at=_now(),
                    error=f"{type(exc).__name__}: {str(exc)[:500]}")
    _store_task(task)


@router.get("/catalog", dependencies=[Depends(_require_operator)])
def catalog() -> dict[str, Any]:
    return {"items": [{"dataset_id": "ecnu-icalk/educhat-sft-002-data-osm",
                       "source_url": "https://huggingface.co/datasets/ecnu-icalk/educhat-sft-002-data-osm",
                       "license": "cc-by-nc-4.0", "revision": "289618b953588bbd1b2a6e217cdd2c53e9cbcf49",
                       "revision_verified": False, "network_status": "not_verified_in_current_environment",
                       "field_schema": {"sequence": "list[str] (alternating question/answer)", "system_prompt": "str"},
                       "local_processing_only": True}]}


@router.post("/sources/fetch", status_code=202)
def fetch_official_source(body: FetchRequest, user: User = Depends(_require_operator)) -> dict[str, Any]:
    fetch_id, source_id = uuid.uuid4().hex, uuid.uuid4().hex
    directory = _user_root(user) / "sources" / source_id
    directory.mkdir(parents=True, exist_ok=False)
    job = {"fetch_id": fetch_id, "owner_key": _owner_key(user), "source_id": source_id,
           "status": "pending", "current_step": "queued", "processed": 0, "total": body.count,
           "created_at": _now(), "started_at": None, "ended_at": None, "error": None}
    with _lock:
        _fetch_jobs[fetch_id] = job
        _atomic_json(directory / "fetch_job.json", job)
    _pool.submit(_run_fetch, fetch_id, str(user.id), _owner_key(user), body.count, source_id, directory)
    return {key: value for key, value in job.items() if key != "owner_key"}


@router.get("/sources/fetch/{fetch_id}", dependencies=[Depends(_require_operator)])
def get_fetch_status(fetch_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    if not re.fullmatch(r"[0-9a-f]{32}", fetch_id):
        raise HTTPException(status_code=404, detail="采集任务不存在")
    with _lock:
        job = _fetch_jobs.get(fetch_id)
    if job is None:
        matches = list((_user_root(user) / "sources").glob("*/fetch_job.json"))
        job = next((_read_json(path) for path in matches if _read_json(path).get("fetch_id") == fetch_id), None)
    if not job or job.get("owner_key") != _owner_key(user):
        raise HTTPException(status_code=404, detail="采集任务不存在")
    return {key: value for key, value in job.items() if key != "owner_key"}


@router.get("/sources", dependencies=[Depends(_require_operator)])
def list_sources(user: User = Depends(_require_operator), db: Session = Depends(get_db)) -> dict[str, Any]:
    directory = _user_root(user) / "sources"
    items = [_read_json(path) for path in directory.glob("*/source_manifest.json")] if directory.is_dir() else []
    assets = {asset.id: asset for asset in db.query(Dataset).filter(Dataset.owner_id == str(user.id)).all()}
    result = []
    for item in sorted(items, key=lambda value: value.get("acquired_at", ""), reverse=True):
        public = {key: value for key, value in item.items() if key not in {"sample_ids", "source_record_ids"}}
        asset = assets.get(item.get("source_id"))
        public["asset_registered"] = asset is not None
        public["asset_status"] = asset.status if asset else None
        result.append(public)
    return {"items": result}


@router.post("/sources/upload", status_code=201)
async def upload_source(
    file: UploadFile = File(...), dataset_id: str = Form(...), source_url: str = Form(...),
    license: str = Form(...), revision: str = Form(...), split: str = Form("local"),
    user: User = Depends(_require_operator),
    db: Session = Depends(get_db),
) -> dict[str, Any]:
    filename = Path(file.filename or "data.jsonl").name
    suffix = Path(filename).suffix.casefold()
    if suffix not in ALLOWED_SUFFIXES:
        raise HTTPException(status_code=400, detail="仅支持 JSONL、JSON 或 Parquet 文件")
    source_id = uuid.uuid4().hex
    directory = _user_root(user) / "sources" / source_id
    directory.mkdir(parents=True, exist_ok=False)
    target = directory / f"source{suffix}"
    size = 0
    try:
        with target.open("wb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    raise HTTPException(status_code=413, detail="上传文件超过 100 MiB 限制")
                output.write(chunk)
        rows, issues, _nonblank, _parse_errors = _read_local_source(target)
        if not rows:
            raise HTTPException(status_code=400, detail="文件中没有可读取的对象记录")
        if len(rows) > MAX_SOURCE_ROWS:
            raise HTTPException(status_code=413, detail="单个数据源最多导入 100,000 条记录")
        if issues:
            raise HTTPException(status_code=400, detail=f"文件包含 {len(issues)} 条不可解析记录，请先修复后再导入")
        source_ids = [str(row.get("id", row.get("hf_row_idx", row.get("row_idx", line)))) for line, row in rows]
        sample_ids = [str(row.get("sample_id") or _stable_sample_id(dataset_id, revision, split, source_id_value))
                      for (_line, row), source_id_value in zip(rows, source_ids)]
        fields = sorted({str(key) for _line, row in rows for key in row})
        field_types = {field: sorted({type(row.get(field)).__name__ for _line, row in rows if field in row})
                       for field in fields}
        file_hash = sha256_file(target)
        raw_version_id = f"raw_{file_hash[:24]}"
        fields_set = set(fields)
        if "data" in fields_set:
            field_mapping = {"instruction": "data[last_user]", "output": "data[last_assistant]",
                             "input": "data[history_turns]", "system": "system_prompt" if "system_prompt" in fields_set else None}
        elif "sequence" in fields_set:
            field_mapping = {"instruction": "sequence[last_user]", "output": "sequence[last_assistant]",
                             "input": "sequence[history_turns]", "system": "system_prompt" if "system_prompt" in fields_set else None}
        else:
            field_mapping = {"instruction": "instruction|question|prompt", "output": "output|answer|response",
                             "input": "input|context", "system": "system|system_prompt"}
        manifest = {
            "manifest_version": 1, "source_id": source_id, "dataset_id": dataset_id.strip(),
            "source_url": source_url.strip(), "license": license.strip().casefold(),
            "revision": revision.strip(), "split": split.strip() or "local",
            "sample_count": len(rows), "sample_ids": sample_ids, "source_record_ids": source_ids,
            "field_names": fields, "field_types": field_types, "stored_filename": target.name,
            "field_mapping": field_mapping,
            "file": target.name, "file_sha256": file_hash, "sha256": file_hash,
            "raw_file_path": str(target.resolve()), "file_size_bytes": size,
            "file_mtime_ns": target.stat().st_mtime_ns,
            "acquired_at": _now(), "sampling_method": "user_provided_local_file; no sampling performed by API",
            "provenance_method": "user_attested_local_import", "revision_verified": False,
            "license_verified": False, "redistribution_authorized": False,
            "source_type": "local_file", "license_verification_status": "unverified",
            "revision_verification_status": "unverified", "created_at": _now(),
            "version_id": raw_version_id, "status": "imported",
        }
        _atomic_json(directory / "source_manifest.json", manifest)
        version_dir = directory / "versions"
        version_dir.mkdir(parents=True, exist_ok=True)
        sample_ids_path = version_dir / f"{raw_version_id}_sample_ids.jsonl"
        sample_ids_path.write_text("".join(json.dumps(sample_id, ensure_ascii=False) + "\n" for sample_id in sample_ids), encoding="utf-8")
        _atomic_json(version_dir / f"{raw_version_id}.json", {
            "version_id": raw_version_id, "parent_version_id": None, "version_type": "raw",
            "source_id": source_id, "dataset_id": dataset_id.strip(), "sample_count": len(rows),
            "sample_ids_path": str(sample_ids_path.resolve()), "raw_file_path": str(target.resolve()), "sha256": file_hash,
            "license": license.strip().casefold(), "license_verification_status": "unverified",
            "revision": revision.strip(), "revision_verification_status": "unverified",
            "authorization_status": "unverified", "status": "imported", "created_at": manifest["created_at"],
        })
        asset = Dataset(
            id=source_id,
            name=dataset_id.strip()[:200],
            description="预立项本地数据源；官方版本和许可待核验。",
            data_type="parquet" if suffix in {".parquet", ".pq"} else "json",
            status="ready",
            size_bytes=size,
            row_count=len(rows),
            column_count=len(fields),
            tags=["preproject", "raw", "local_import", "provenance_unverified"],
            columns_info={"source_id": source_id, "version_id": raw_version_id, "field_names": fields,
                          "field_types": field_types, "license_verification_status": "unverified",
                          "revision_verification_status": "unverified"},
            owner_id=str(user.id),
        )
        db.add(asset)
        db.commit()
        return {key: value for key, value in manifest.items() if key != "sample_ids"}
    except HTTPException:
        shutil.rmtree(directory, ignore_errors=True)
        raise
    except Exception as exc:
        db.rollback()
        shutil.rmtree(directory, ignore_errors=True)
        raise HTTPException(status_code=400, detail=f"数据文件验证失败：{type(exc).__name__}") from None
    finally:
        await file.close()


@router.get("/sources/{source_id}", dependencies=[Depends(_require_operator)])
def get_source(source_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    manifest, path = _load_source(user, source_id)
    unchanged = _unchanged_since_hash(path, manifest)
    return {"source": {key: value for key, value in manifest.items() if key != "sample_ids"},
            "file_unchanged_since_import_hash": unchanged,
            "preview": {"field_names": manifest.get("field_names", []), "row_count": manifest.get("sample_count")}}


@router.get("/sources/{source_id}/preview", dependencies=[Depends(_require_operator)])
def preview_source(source_id: str, offset: int = Query(default=0, ge=0), limit: int = Query(default=10, ge=1, le=100),
                   user: User = Depends(_require_operator)) -> dict[str, Any]:
    manifest, path = _load_source(user, source_id)
    rows, issues, _nonblank, _errors = _read_local_source(path)
    task_stub = {"source_id": source_id, "parameters": {"version_name": "raw-preview", "cleaning_enabled": True}}
    preview_fields = ("sample_id", "source_record_id", "instruction", "input", "output", "system",
                      "source_field_mapping", "processing_status", "processing_reasons")
    samples = []
    for line_number, row in rows[offset:offset + limit]:
        row_key = row.get("id", row.get("hf_row_idx", row.get("row_idx", line_number)))
        sample_id = str(row.get("sample_id") or _stable_sample_id(
            str(manifest.get("dataset_id", "local-unknown")), str(manifest.get("revision", "unversioned")),
            str(manifest.get("split", "local")), str(row_key)))
        normalized = _safe_normalized_sample(user, task_stub, sample_id, rows)
        if normalized:
            samples.append({key: normalized.get(key) for key in preview_fields})
    return {"source_id": source_id, "version_id": manifest.get("version_id"), "offset": offset,
            "limit": limit, "total": len(rows), "parse_issue_count": len(issues), "samples": samples,
            "privacy_engine": "privacy-patterns-v1", "privacy_residual_scan": "passed for displayed fields"}


@router.get("/versions", dependencies=[Depends(_require_operator)])
def list_versions(offset: int = Query(default=0, ge=0), limit: int = Query(default=50, ge=1, le=200),
                  user: User = Depends(_require_operator)) -> dict[str, Any]:
    root = _user_root(user)
    paths = list(root.glob("sources/*/versions/*.json")) + list(root.glob("tasks/*/versions/*.json"))
    versions = [_read_json(path) for path in paths]
    versions.sort(key=lambda value: value.get("created_at", ""), reverse=True)
    return {"items": versions[offset:offset + limit], "total": len(versions), "offset": offset, "limit": limit}


@router.get("/versions/{version_id}", dependencies=[Depends(_require_operator)])
def get_version(version_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    return {"version": _read_json(_version_record_path(user, version_id))}


@router.get("/version-comparison", dependencies=[Depends(_require_operator)])
def compare_versions(left: str, right: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    versions = [_read_json(_version_record_path(user, key)) for key in (left, right)]
    def load(version: dict[str, Any]) -> dict[str, dict[str, Any]]:
        path = version.get("processed_file_path") or version.get("processed_path")
        if path and Path(path).is_file():
            return {str(row["sample_id"]): row for row in _jsonl_rows(Path(path)) if row.get("sample_id")}
        ids = version.get("sample_ids_path")
        if ids and Path(ids).is_file():
            return {str(json.loads(line)): {} for line in Path(ids).read_text(encoding="utf-8").splitlines() if line.strip()}
        raise HTTPException(status_code=410, detail="版本样本文件不存在")
    before, after = [load(version) for version in versions]
    left_ids, right_ids = set(before), set(after)
    common = left_ids & right_ids
    comparable = all(before[key] and after[key] for key in common)
    fields = ("instruction", "input", "output", "system")
    changed = sorted(key for key in common if any(before[key].get(f) != after[key].get(f) for f in fields)) if comparable else []
    state_changed = sorted(key for key in common if before[key].get("processing_status") != after[key].get("processing_status")) if comparable else []
    return {"left": left, "right": right, "added_count": len(right_ids-left_ids), "removed_count": len(left_ids-right_ids),
            "changed_count": len(changed) if comparable else None, "status_changed_count": len(state_changed) if comparable else None,
            "added_sample_ids": sorted(right_ids-left_ids)[:100], "removed_sample_ids": sorted(left_ids-right_ids)[:100],
            "changed_sample_ids": changed[:100], "reason": None if comparable else "原始版本仅登记样本 ID，内容差异不可直接比较。"}


@router.post("/versions/{version_id}/release-candidate", dependencies=[Depends(_require_operator)])
def create_release_candidate(version_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    version_path = _version_record_path(user, version_id)
    version = _read_json(version_path)
    reasons = []
    if version.get("revision_verification_status") != "verified":
        reasons.append("revision未通过官方核验")
    if version.get("license_verification_status") != "verified":
        reasons.append("许可未通过官方核验")
    if version.get("authorization_status") != "authorized":
        reasons.append("未取得再分发授权")
    gate = version.get("quality_gate") or {}
    if gate.get("release_eligible") is not True:
        reasons.append("质量准入门未允许发布")
    if reasons:
        raise HTTPException(status_code=409, detail={"message": "当前数据版本不能生成发布候选", "reasons": reasons})
    candidate_id = "candidate_" + hashlib.sha256(version_id.encode("utf-8")).hexdigest()[:24]
    qualified_path = version.get("qualified_file_path")
    if not qualified_path or not Path(qualified_path).is_file():
        raise HTTPException(status_code=409, detail="合格数据池不存在，无法生成发布候选")
    candidate = {**version, "processed_file_path": qualified_path, "version_id": candidate_id, "parent_version_id": version_id,
                 "version_type": "release_candidate", "status": "candidate_ready", "created_at": _now()}
    candidate_dir = version_path.parent
    _atomic_json(candidate_dir / f"{candidate_id}.json", candidate)
    return {"version": candidate}


@router.post("/sources/{source_id}/validate", dependencies=[Depends(_require_operator)])
def validate_source(source_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    manifest, path = _load_source(user, source_id)
    rows, issues, _nonblank, _errors = _read_local_source(path)
    unchanged = _unchanged_since_hash(path, manifest)
    source_defaults = {"dataset_id": manifest.get("dataset_id"), "revision": manifest.get("revision"),
                       "split": manifest.get("split"), "license": manifest.get("license"),
                       "source_id": manifest.get("source_id")}
    schema_issue_count = 0
    for line_number, row in rows:
        normalized = normalize_record(row, defaults=source_defaults, line_number=line_number)
        if not isinstance(normalized.get("instruction"), str) or not normalized["instruction"].strip() or \
           not isinstance(normalized.get("output"), str) or not normalized["output"].strip():
            schema_issue_count += 1
    source_valid = bool(rows) and not issues and schema_issue_count == 0 and unchanged is not False
    if unchanged is True:
        message = "记录可读且SFT结构有效；文件大小/修改时间与导入时一致。哈希只在导入时计算，来源和许可仍为用户声明。"
    elif unchanged is False:
        message = "文件大小或修改时间与导入时不同；请重新导入以生成新的来源版本。"
    else:
        message = "记录可读且SFT结构有效；旧来源未保存修改时间，哈希只在导入时计算，来源和许可仍为用户声明。"
    return {"valid": source_valid, "row_count": len(rows),
            "parse_issue_count": len(issues), "schema_issue_count": schema_issue_count,
            "file_unchanged_since_import_hash": unchanged,
            "hash_recorded_at_import": bool(manifest.get("file_sha256")),
            "revision_verified": False, "license_verified": False,
            "message": message}


@router.get("/tasks", dependencies=[Depends(_require_operator)])
def list_tasks(user: User = Depends(_require_operator)) -> dict[str, Any]:
    directory = _user_root(user) / "tasks"
    items = [_read_json(path) for path in directory.glob("*/task.json")] if directory.is_dir() else []
    for task in items:
        if task.get("status") in {"pending", "running"} and task.get("task_id") not in _tasks:
            task.update(status="failed", current_step="interrupted", ended_at=_now(),
                        error="后端进程已重启，任务未自动续跑；请检查数据后重试。")
            _atomic_json(Path(task["task_dir"]) / "task.json", task)
    return {"items": [{key: value for key, value in task.items() if key not in {"owner_key", "task_dir"}}
                       for task in sorted(items, key=lambda value: value.get("created_at", ""), reverse=True)]}


@router.post("/tasks", status_code=202)
def create_task(body: CreateTaskRequest, user: User = Depends(_require_operator)) -> dict[str, Any]:
    manifest, input_path = _load_source(user, body.source_id)
    if not body.privacy_enabled:
        raise HTTPException(status_code=400, detail="预立项数据任务要求启用隐私检测与脱敏")
    config_fingerprint = hashlib.sha256(json.dumps(body.model_dump(), sort_keys=True).encode()).hexdigest()
    existing = [task for task in list_tasks(user)["items"]
                if task.get("source_id") == body.source_id and task.get("config_fingerprint") == config_fingerprint
                and task.get("status") in {"pending", "running"}]
    if existing:
        return {"task": existing[0], "duplicate_submission": True}
    task_id = uuid.uuid4().hex
    task_dir = _user_root(user) / "tasks" / task_id
    task_dir.mkdir(parents=True, exist_ok=False)
    task = {"task_id": task_id, "owner_key": _owner_key(user), "task_dir": str(task_dir),
            "source_id": body.source_id, "status": "pending", "current_step": "queued", "processed": 0,
            "total": manifest["sample_count"], "created_at": _now(), "started_at": None, "ended_at": None,
            "error": None, "config_fingerprint": config_fingerprint,
            "parameters": {key: value for key, value in body.model_dump().items() if key != "source_id"}}
    event = threading.Event()
    with _lock:
        _tasks[task_id] = task
        _cancel_events[task_id] = event
        _atomic_json(task_dir / "task.json", task)
    _pool.submit(_run_task, task_id, _owner_key(user), manifest, input_path, task_dir, body)
    return {"task": {key: value for key, value in task.items() if key not in {"owner_key", "task_dir"}},
            "duplicate_submission": False}


@router.get("/tasks/{task_id}", dependencies=[Depends(_require_operator)])
def get_task(task_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    return {key: value for key, value in task.items() if key not in {"owner_key", "task_dir"}}


@router.post("/tasks/{task_id}/cancel", dependencies=[Depends(_require_operator)])
def cancel_task(task_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    with _lock:
        task = _tasks.get(task_id, task)
        if task.get("status") not in {"pending", "running"}:
            raise HTTPException(status_code=409, detail="仅 pending 或 running 任务可以取消")
        event = _cancel_events.get(task_id)
        if event:
            event.set()
        else:
            task.update(status="cancelled", current_step="cancelled", ended_at=_now())
            _store_task(task)
    return {"task_id": task_id, "cancel_requested": True}


@router.post("/tasks/{task_id}/retry", status_code=202, dependencies=[Depends(_require_operator)])
def retry_task(task_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    if task.get("status") != "failed":
        raise HTTPException(status_code=409, detail="只有失败任务可以重试")
    params = dict(task.get("parameters", {}))
    params["source_id"] = task["source_id"]
    return create_task(CreateTaskRequest(**params), user)


@router.get("/tasks/{task_id}/results", dependencies=[Depends(_require_operator)])
def task_results(task_id: str, user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    if task.get("status") != "completed":
        raise HTTPException(status_code=409, detail="任务尚未完成")
    output_dir = Path(task["task_dir"]) / "output"
    issues_path = output_dir / "review_queue.jsonl"
    issues = []
    if issues_path.is_file():
        for line in issues_path.read_text(encoding="utf-8").splitlines()[:100]:
            try:
                issues.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    version_dir = Path(task["task_dir"]) / "versions" / str(task.get("reviewed_version_id", ""))
    files = [name for name in sorted(DOWNLOADABLE) if (output_dir / name).is_file()]
    files.extend(name for name in sorted(DOWNLOADABLE) if name.startswith("reviewed_") and (version_dir / name).is_file())
    statistics = task.get("statistics")
    quality = task.get("quality")
    gate = task.get("gate")
    reviewed_quality_path = version_dir / "reviewed_quality_metrics.json"
    reviewed_stats_path = version_dir / "reviewed_statistics.json"
    if reviewed_quality_path.is_file() and reviewed_stats_path.is_file():
        quality = _read_json(reviewed_quality_path)
        statistics = _read_json(reviewed_stats_path)
        version_record = _read_json(Path(task["task_dir"]) / "versions" / f"{task['reviewed_version_id']}.json")
        gate = version_record.get("quality_gate", gate)
    return {"statistics": statistics, "quality": quality, "gate": gate,
            "reviewed_version_id": task.get("reviewed_version_id"), "review_samples": issues, "files": files}


@router.get("/tasks/{task_id}/samples", dependencies=[Depends(_require_operator)])
def task_samples(task_id: str, offset: int = Query(default=0, ge=0), limit: int = Query(default=10, ge=1, le=50),
                 issue: str | None = Query(default=None, max_length=160), user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    if task.get("status") != "completed":
        raise HTTPException(status_code=409, detail="任务尚未完成")
    output_path = Path(task["task_dir"]) / "output" / "processed.jsonl"
    if not output_path.is_file():
        raise HTTPException(status_code=404, detail="处理结果文件不存在")
    records = _jsonl_rows(output_path)
    if issue:
        records = [row for row in records if (issue == "privacy_hit" and any(row.get("privacy_hits", {}).values()))
                   or issue in row.get("processing_reasons", [])]
    _manifest, input_path = _load_source(user, str(task["source_id"]))
    source_rows, _issues, _count, _errors = _read_local_source(input_path)
    task_stub = {**task, "parameters": {**task.get("parameters", {}), "cleaning_enabled": False}}
    fields = ("instruction", "input", "output", "system")
    samples = []
    for row in records[offset:offset+limit]:
        before = _safe_normalized_sample(user, task_stub, str(row["sample_id"]), source_rows)
        samples.append({"sample_id": row["sample_id"], "source_record_id": row.get("source_record_id"),
                        "before": {key: before.get(key, "") for key in fields} if before else None,
                        "after": {key: row.get(key, "") for key in fields}, "status": row.get("processing_status"),
                        "reasons": row.get("processing_reasons", []), "cleaning_changes": row.get("cleaning_changes", []),
                        "duplicate_type": row.get("duplicate_type"), "privacy_hits": row.get("privacy_hits", {})})
    return {"items": samples, "total": len(records), "offset": offset, "limit": limit,
            "notice": "对比两侧均经隐私规则处理；来源侧为标准化后的脱敏预览。"}


@router.get("/tasks/{task_id}/review-items", dependencies=[Depends(_require_operator)])
def review_items(task_id: str, offset: int = Query(default=0, ge=0), limit: int = Query(default=20, ge=1, le=100),
                 issue_type: str | None = Query(default=None, max_length=160),
                 user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    if task.get("status") != "completed":
        raise HTTPException(status_code=409, detail="任务尚未完成")
    items = _jsonl_rows(Path(task["task_dir"]) / "output" / "review_queue.jsonl")
    state_path = Path(task["task_dir"]) / "review_state.json"
    states = _read_json(state_path) if state_path.is_file() else {"items": {}}
    state_map = states.get("items", {}) if isinstance(states.get("items"), dict) else {}
    if issue_type:
        items = [item for item in items if issue_type in item.get("reasons", [])]
    _manifest, input_path = _load_source(user, str(task["source_id"]))
    rows, _issues, _nonblank, _errors = _read_local_source(input_path)
    page = []
    for item in items[offset:offset + limit]:
        sample_id = str(item.get("sample_id") or "")
        state = state_map.get(sample_id, {})
        record = {key: item.get(key) for key in ("sample_id", "line_number", "status", "reasons", "source_record_id", "near_duplicate_sample_ids")}
        record["decision"] = state.get("decision", "pending")
        normalized = _safe_normalized_sample(user, task, sample_id, rows) if sample_id else None
        if normalized:
            record["preview"] = {key: normalized.get(key) for key in ("instruction", "input", "output", "system", "source_field_mapping")}
            if state.get("decision") == "edit" and isinstance(state.get("edited_content"), dict):
                record["preview"].update(state["edited_content"])
        page.append(record)
    reviewed_id = task.get("reviewed_version_id")
    reviewed_path = Path(task["task_dir"]) / "versions" / str(reviewed_id or "") / "reviewed_processed.jsonl"
    reviewed_ids = {str(row.get("sample_id")) for row in _jsonl_rows(reviewed_path)} if reviewed_id else set()
    pending = sum(1 for item in items if (state_map.get(str(item.get("sample_id", "")), {}).get("decision") is None
                  or (state_map.get(str(item.get("sample_id", "")), {}).get("decision") == "edit"
                      and str(item.get("sample_id", "")) not in reviewed_ids)))
    return {"items": page, "total": len(items), "offset": offset, "limit": limit, "pending_count": pending}


@router.get("/tasks/{task_id}/reviews", dependencies=[Depends(_require_operator)])
def review_history(task_id: str, offset: int = Query(default=0, ge=0), limit: int = Query(default=50, ge=1, le=200),
                   user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    items = _jsonl_rows(Path(task["task_dir"]) / "reviews.jsonl")
    items.sort(key=lambda row: row.get("reviewed_at", ""), reverse=True)
    return {"items": items[offset:offset + limit], "total": len(items), "offset": offset, "limit": limit}


@router.post("/tasks/{task_id}/reviews", status_code=201, dependencies=[Depends(_require_operator)])
def submit_review(task_id: str, body: ReviewRequest, user: User = Depends(_require_operator)) -> dict[str, Any]:
    task = _get_task(user, task_id)
    if task.get("status") != "completed":
        raise HTTPException(status_code=409, detail="任务尚未完成")
    task_dir = Path(task["task_dir"])
    issue = next((item for item in _jsonl_rows(task_dir / "output" / "review_queue.jsonl")
                  if item.get("sample_id") == body.sample_id), None)
    if issue is None:
        raise HTTPException(status_code=404, detail="样本不在该任务的待复核队列中")
    prior_path = task_dir / "review_state.json"
    prior = _read_json(prior_path).get("items", {}).get(body.sample_id, {}) if prior_path.is_file() else {}
    normalized = _safe_normalized_sample(user, task, body.sample_id)
    if normalized is None:
        raise HTTPException(status_code=404, detail="原始样本不存在")
    content_fields = ("instruction", "input", "output", "system")
    before_content = {key: normalized.get(key, "") for key in content_fields}
    before_hash = hashlib.sha256(json.dumps(before_content, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    edited = prior.get("edited_content") if isinstance(prior.get("edited_content"), dict) else None
    if body.decision == "edit":
        if not body.edited_content:
            raise HTTPException(status_code=422, detail="编辑复核必须提交 edited_content")
        if set(body.edited_content) - set(content_fields):
            raise HTTPException(status_code=422, detail="仅允许编辑 instruction、input、output、system 字段")
        config = _load_pipeline_config()
        draft = {**normalized, "processing_status": "keep", "processing_reasons": [], "status_history": [],
                 "_source_fields": {}}
        draft.update(body.edited_content)
        clean_record(draft, config.get("engineering_screens", {}))
        _hits, _masks, edit_residual = inspect_and_mask(draft, config.get("privacy", {}))
        if any(edit_residual.values()):
            raise HTTPException(status_code=422, detail="编辑内容脱敏后仍有敏感信息残留，未保存")
        edited = {key: str(draft.get(key, "")) for key in content_fields}
    safe_notes_record = {**normalized, "instruction": body.notes, "input": "", "output": "", "system": "",
                         "processing_status": "keep", "processing_reasons": [], "status_history": [], "_source_fields": {}}
    inspect_and_mask(safe_notes_record, _load_pipeline_config().get("privacy", {}))
    safe_notes = str(safe_notes_record.get("instruction", ""))
    after_content = edited or before_content
    reviewed_at = _now()
    event = {"sample_id": body.sample_id, "task_id": task_id, "version_id": task.get("version_id"),
             "reviewer_id": str(user.id), "issue_type": body.issue_type or (issue.get("reasons") or ["unspecified"])[0],
             "decision": body.decision, "before_hash": before_hash,
             "after_hash": hashlib.sha256(json.dumps(after_content, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest(),
             "reviewed_at": reviewed_at, "notes": safe_notes}
    state_path = task_dir / "review_state.json"
    states = _read_json(state_path) if state_path.is_file() else {"items": {}}
    states.setdefault("items", {})[body.sample_id] = {
        "decision": body.decision, "edited_content": edited, "original_status": issue.get("status", "review"),
        "issue_type": event["issue_type"], "reviewed_at": reviewed_at,
    }
    with _lock:
        _atomic_json(state_path, states)
        with (task_dir / "reviews.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
    try:
        version = _rebuild_reviewed_version(user, task, states)
    except Exception as exc:
        task["review_rebuild_error"] = f"{type(exc).__name__}: {str(exc)[:300]}"
        _store_task(task)
        raise HTTPException(status_code=500, detail="复核记录已保存，但重新处理和质量复算失败；请查看任务错误后重试。") from None
    return {"review": event, "version": version, "quality_recomputed": True}


@router.get("/tasks/{task_id}/files/{filename}", dependencies=[Depends(_require_operator)])
def download_result(task_id: str, filename: str, user: User = Depends(_require_operator)) -> FileResponse:
    task = _get_task(user, task_id)
    if task.get("status") != "completed" or filename not in DOWNLOADABLE:
        raise HTTPException(status_code=404, detail="结果文件不存在")
    base_dir = (Path(task["task_dir"]) / "versions" / str(task.get("reviewed_version_id", ""))
                if filename.startswith("reviewed_") else Path(task["task_dir"]) / "output")
    path = (base_dir / filename).resolve()
    if path.parent != base_dir.resolve() or not path.is_file():
        raise HTTPException(status_code=404, detail="结果文件不存在")
    media_type = "application/x-ndjson" if filename.endswith(".jsonl") else "application/json" if filename.endswith(".json") else "text/markdown"
    return FileResponse(path, media_type=media_type, filename=filename)
