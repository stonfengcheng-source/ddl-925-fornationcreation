# 前端测试和演示

测试命令：`cd frontend; npm ci; npm test; npm run build`。构建包含 TypeScript 检查。页面相关组件测试使用 API 桩验证交互，不等于真实浏览器操作；真实 API 运行结果另见 `real_data_test_report.md`。本轮未使用浏览器，也没有伪造截图。

第九轮全量 Vitest：13 个文件、61 项通过，其中预立项页面定向测试 15 项；覆盖导入、验证、配置、轮询、独立失败重试、N/A、筛选、审核、版本、下载、恢复、取消请求及旧任务结果隔离。构建和 TypeScript 检查通过，存在动态导入混用与大 chunk 警告。数据流水线 13 项及后端复核/安全定向测试 5 项通过。真实 HTTP 与 CLI 的详细范围见对应报告；其他后端全量测试未在本轮全部执行。

演示脚本为 `scripts/start_demo.ps1`、`scripts/smoke_test.ps1` 和 `scripts/stop_demo.ps1`。默认使用隔离 SQLite、隔离存储及本机免密开发账号，只适合本机演示。页面提供 TEST-ONLY 初始化入口；真实数据需手动上传，页面不会自动伪造或回退到模拟统计。

第九轮 ZIP 已解压到新目录；流水线测试 13 项通过。使用本机 npm 缓存执行 `npm ci --offline --ignore-scripts` 后，复用已有 Python 环境启动前后端、健康检查并停止均通过。未验证全新 Python 环境的依赖下载及安装。
