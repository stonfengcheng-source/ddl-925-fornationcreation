import * as React from 'react';
import { importPreprojectDemo, previewPreprojectSource, uploadPreprojectSource, validatePreprojectSource } from '@/services/api/preprojectData';
import { useWorkspace } from '../layout/PreprojectLayout';

export function SourcesPage() {
  const { sources, sourceId, chooseSource, go, refreshSources } = useWorkspace();
  const [file, setFile] = React.useState<File | null>(null); const [error, setError] = React.useState(''); const [notice, setNotice] = React.useState('');
  const [busy, setBusy] = React.useState(false); const [offset, setOffset] = React.useState(0); const [preview, setPreview] = React.useState<Array<Record<string, string>>>([]);
  const [validatedSource, setValidatedSource] = React.useState(() => sessionStorage.getItem('pp-validated-source') || '');
  const [metadata, setMetadata] = React.useState({ dataset_id: '', source_url: '', license: '', revision: '', split: 'local' });
  React.useEffect(() => { let disposed = false; setPreview([]); if (sourceId) previewPreprojectSource(sourceId, offset, 5).then((data) => { if (!disposed) setPreview(data.samples); }).catch(() => { if (!disposed) setError('样本预览加载失败'); }); return () => { disposed = true; }; }, [sourceId, offset]);
  const upload = async (event: React.FormEvent) => { event.preventDefault(); if (!file) return; setBusy(true); setError(''); try { const result = await uploadPreprojectSource(file, metadata); refreshSources(); chooseSource(result.source_id); setNotice(`已导入 ${result.sample_count} 条，来源与许可仍需核验。`); } catch { setError('上传失败，请检查文件和来源信息。'); } finally { setBusy(false); } };
  const demo = async () => { setBusy(true); setError(''); try { const result = await importPreprojectDemo(); refreshSources(); chooseSource(result.source_id); setNotice('已登记 TEST-ONLY 夹具，与用户数据分开。'); } catch { setError('无法导入 TEST-ONLY 夹具；请确认本地演示服务已启动。'); } finally { setBusy(false); } };
  const validate = async () => { try { const value = await validatePreprojectSource(sourceId); const accepted = value.valid ? sourceId : ''; setValidatedSource(accepted); sessionStorage.setItem('pp-validated-source', accepted); setNotice(String(value.message || (value.valid ? '验证通过' : '验证未通过'))); } catch { setValidatedSource(''); sessionStorage.removeItem('pp-validated-source'); setError('验证失败，请检查数据源。'); } };
  return <div className="grid gap-4 lg:grid-cols-2">
    <section className="rounded-xl border bg-white p-5 space-y-3"><h2 className="text-lg font-semibold">导入数据</h2><p className="text-sm">上传已有 EduChat JSONL、JSON 或 Parquet。没有真实数据时，可使用独立标识的测试夹具。</p><button disabled={busy} onClick={demo} className="rounded border border-blue-500 px-3 py-2">导入 TEST-ONLY 演示数据</button>
      <form onSubmit={upload} className="space-y-3"><label className="block">数据文件<input aria-label="数据文件" className="block" type="file" accept=".json,.jsonl,.parquet,.pq" onChange={(e) => setFile(e.target.files?.[0] || null)} /></label>
        {(['dataset_id', 'source_url', 'license', 'revision', 'split'] as const).map((key) => <label className="block text-sm" key={key}>{({dataset_id:'数据集 ID', source_url:'来源链接', license:'许可', revision:'版本', split:'数据分片'})[key]}<input aria-label={key} required value={metadata[key]} onChange={(e) => setMetadata({ ...metadata, [key]: e.target.value })} className="mt-1 w-full rounded border p-2" /></label>)}
        <button disabled={!file || busy} className="rounded bg-blue-700 px-4 py-2 text-white disabled:opacity-50">上传数据</button></form>
      {error && <p role="alert" className="text-red-700">{error}</p>}{notice && <p role="status">{notice}</p>}</section>
    <section className="rounded-xl border bg-white p-5 space-y-3"><h2 className="text-lg font-semibold">已登记数据源</h2><p className="text-sm">{sources.length} 个来源 · {sources.reduce((n, item) => n + item.sample_count, 0)} 条</p>
      {sources.map((source) => <button key={source.source_id} onClick={() => { setOffset(0); chooseSource(source.source_id); }} className={`block w-full rounded border p-3 text-left ${sourceId === source.source_id ? 'border-blue-600 bg-blue-50' : ''}`}><b>{source.dataset_id}</b><span className="ml-2">{source.sample_count} 条</span><div className="text-xs">{source.source_type === 'test_fixture' ? 'TEST-ONLY 演示数据' : '用户数据 · 来源及许可待核验'}</div></button>)}
      {!sources.length && <p>暂无数据，请先上传或导入 TEST-ONLY 夹具。</p>}
      <div className="flex gap-2"><button disabled={!sourceId} onClick={validate} className="rounded border px-3 py-2">验证数据源</button><button disabled={!sourceId || validatedSource !== sourceId} onClick={() => go('pipelines')} className="rounded bg-blue-700 px-3 py-2 text-white disabled:opacity-50">选择数据并开始处理</button></div>{sourceId && validatedSource !== sourceId && <p className="text-xs">请先验证选中的数据源。</p>}
      {sourceId && <><h3>脱敏样本预览</h3>{preview.map((row) => <article key={row.sample_id} className="rounded bg-gray-50 p-3 text-sm"><div>{row.sample_id} · 原始行 {row.source_record_id}</div><p>用户：{row.instruction}</p><p>助手：{row.output}</p>{row.input && <details><summary>对话历史</summary><pre className="whitespace-pre-wrap">{row.input}</pre></details>}</article>)}<div className="flex gap-4"><button disabled={!offset} onClick={() => setOffset(Math.max(0, offset - 5))}>上一页</button><button disabled={preview.length < 5} onClick={() => setOffset(offset + 5)}>下一页</button></div></>}
    </section></div>;
}
